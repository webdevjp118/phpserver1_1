const $ = (q) => document.querySelector(q)
const getTransformCss = (degrees) => {
  let cssText = ['-webkit-', '-moz-', '-ms-', ''].map((item) => {
    return `${item}transform: rotate(${degrees}deg)`
  })
  
  return cssText.join(';')
}

const bar = $('#progress-bar')
const text = $('.text')
const half = $('.half')
const full = $('.full')

const updateText = (value) => {
  text.textContent = value
}
const updateProgressBar = (value) => {
  const degrees = Math.abs(value - 50) / 50 * 180
  
  if (value < 1) {
    bar.className = ''
  }
  else if (value < 50) {
    half.style.cssText = getTransformCss(-degrees)
    bar.className = 'half'
  }
  else {
    half.style.cssText = getTransformCss(0)
    full.style.cssText = getTransformCss(degrees)
    bar.className = 'full'
  }
}

$('.value').addEventListener('input', (e) => {
  let value = e.target.value
  updateText(value)
  updateProgressBar(value)
})

$('.size').addEventListener('input', (e) => {
  let value = e.target.value
  bar.style.fontSize = `${value}px`
})

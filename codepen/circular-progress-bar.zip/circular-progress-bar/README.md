# circular progress bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tomik23/pen/GRpMZBz](https://codepen.io/Tomik23/pen/GRpMZBz).

Simple circular progress bar - examples. From now on, one call runs multiple circular-progress-bar. IntersectionObserver support, the animation starts when the individual chart appears in the view. https://github.com/tomik23/circular-progress-bar
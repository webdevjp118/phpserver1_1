<?php
get_header();
?>
<main>
	<section class="information">
		<div class="info_wrap" style="height:45vh;">
      <p style="text-align: center">
        この度は、お問い合わせいただきありがとうございます。
内容を確認次第、担当者よりご連絡をさせていただきます。
      </p>
    </div>
	</section>
</main>
<?php
get_footer();

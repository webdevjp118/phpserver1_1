<?php
get_header();
?>
<main>
	<section class="information">
		<div class="info_wrap" style="height:45vh;">
      <p style="text-align: center">
        Failed
      </p>
    </div>
	</section>
</main>
<?php
get_footer();

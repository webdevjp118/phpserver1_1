# Water Ripple Effect - JQuery Ripple

A Pen created on CodePen.io. Original URL: [https://codepen.io/jenishhrestha/pen/PMQdPP](https://codepen.io/jenishhrestha/pen/PMQdPP).

A beautiful water ripple by using a jQuery plugin called jQuery Ripples.
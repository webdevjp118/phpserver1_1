<?php
     function has_loading_screen(){
       $options = get_design_plus_option();
?>
<script>

 <?php if(wp_is_mobile()) { ?>
 jQuery(window).bind("pageshow", function(event) {
    if (event.originalEvent.persisted) {
      window.location.reload()
    }
 });
 <?php }; ?>

 jQuery(document).ready(function($){

  <?php
       // front page : pause slider while load screen is displayed -----------------------------------
       if(is_front_page()) {
         if($options['index_header_content_type'] == 'type1') {
           echo "$('#index_slider').slick('slickPause');\n";
         }
         if($options['show_index_news']) {
           echo "$('#index_news').slick('slickPause');\n";
         }
         foreach($options['contents_builder'] as $content) :
           if($content['cb_content_select'] == 'carousel') {
             echo "$('.index_carousel').slick('slickPause');\n";
             break;
           }
         endforeach;
       };
  ?>

  function after_load() {
    $('#site_loader_overlay').delay(600).fadeOut(900);

    <?php
         // responsive script ---------------------------
         responsive_script();
    ?>

    <?php
         // front page -----------------------------------
         if(is_front_page()) {
    ?>
    $('#index_slider .item').removeClass('slick-active');
    <?php  if($options['index_header_content_type'] == 'type1') { ?>
    $('#index_slider').slick('setPosition');
    $('#index_slider').slick('slickPlay');
    <?php
           }
           if($options['index_header_content_type'] == 'type2' || $options['index_header_content_type'] == 'type3') {
    ?>
    $('#index_slider .caption.pc').addClass('animate');
    <?php
           };
           if($options['show_index_news']) {
    ?>
    $('#index_news').slick('setPosition');
    $('#index_news').addClass('animate');
    $('#index_news').on('transitionend webkitTransitionEnd', function(){
      $('#index_news').slick('slickPlay');
    });
    <?php
           };
           foreach($options['contents_builder'] as $content) :
             if($content['cb_content_select'] == 'carousel') {
    ?>
    $('.index_carousel').slick('setPosition');
    $('.index_carousel').slick('slickPlay');
    <?php
               break;
             }
           endforeach;
         };
         // page builder -----------------------------------
         if(is_single() || is_page()) {
           if(page_builder_has_widget('pb-widget-slider')) {
    ?>
    $('.pb_slider').slick('setPosition');
    <?php
           };
         };
    ?>

    <?php
         // work archive page (animation by scroll) --------------
         if(is_post_type_archive('work')) {
           work_archive_script();
         };
    ?>

  }

  <?php if ($options['load_icon'] != 'type4') { ?>
  $(window).load(function () {
    after_load();
  });
  <?php }; ?>

  $(function(){
    <?php if ($options['load_icon'] == 'type4') { ?>
    $('#site_loader_logo').addClass('active');
    <?php }; ?>
    setTimeout(function(){
      if( $('#site_loader_overlay').is(':visible') ) {
        after_load();
      }
    }, <?php if($options['load_time']) { echo esc_html($options['load_time']); } else { echo '7000'; }; ?>);
  });

 });

</script>
<?php } ?>
<?php
     // no loading ------------------------------------------------------------------------------------------------------------------
     function no_loading_screen(){
       $options = get_design_plus_option();
?>
<script>
jQuery(document).ready(function($){

  <?php
       // responsive script ----------------------------
       responsive_script();
  ?>

  <?php
       // front page -----------------------------------
       if(is_front_page()) {
  ?>
  $('#index_slider .item').removeClass('slick-active');
  <?php if($options['index_header_content_type'] == 'type2' || $options['index_header_content_type'] == 'type3') { ?>
  $('#index_slider .caption.pc').addClass('animate');
  <?php
         };
         if($options['show_index_news']) {
  ?>
  $('#index_news').slick('slickPause');
  $('#index_news').addClass('animate');
  $('#index_news').on('transitionend webkitTransitionEnd', function(){
    $('#index_news').slick('slickPlay');
  });
  <?php
         };
       };
  ?>

  <?php
       // work archive page (animation by scroll) --------------
       if(is_post_type_archive('work')) {
         work_archive_script();
       };
  ?>

});
</script>
<?php } ?>
<?php
     // responsive script ----------------------------------------------
     function responsive_script(){
       $options = get_design_plus_option();
?>
  $('#tab_button_list').addClass('animate');

  var mqls = [
    window.matchMedia("(min-width: 1051px)"),
    window.matchMedia("(max-width: 651px)")
  ]
  function mediaqueryresponse(mql){
    if (mqls[0].matches){ // over 1051px
      if( $(body).hasClass('header_fix') ) {
        $('.animate_pc').each(function(){
          $(this).addClass('no_animate');
        });
      } else {
        $('.animate_pc').each(function(i){
          $(this).delay(i * 900).queue(function(next) {
            $(this).addClass('animate');
            next();
          });
        });
      }
      <?php if( is_front_page() && ($options['index_header_content_height'] == 'type2') ) { ?>
      var hSize = window.innerHeight;
      $('#index_header_content').height(hSize);
      $('#index_slider .item .slice_image').height(hSize);
      $(window).bind("resize orientationchange", function() {
        var hSize = window.innerHeight;
        $('#index_header_content').height(hSize);
        $('#index_slider .item .slice_image').height(hSize);
      });
      <?php }; ?>
    }
    if (mqls[1].matches){ // under 651px
      $('.animate_mobile').each(function(i){
        $(this).delay(i * 900).queue(function(next) {
          $(this).addClass('animate2');
          next();
        });
      });
      <?php if(is_front_page()) { ?>
      var hSize = window.innerHeight - 60;
      $('#index_header_content').height(hSize);
      $('#index_slider .item .slice_image').height(hSize);
      var windowWidth = $(window).width();
      $(window).bind("resize orientationchange", function() {
        if ($(window).width() != windowWidth) {
          var hSize = window.innerHeight - 60;
          $('#index_header_content').height(hSize);
          $('#index_slider .item .slice_image').height(hSize);
          windowWidth = $(window).width();
        }
      });
      <?php }; ?>
    }
    if (!mqls[0].matches && !mqls[1].matches){ // between 652 ~ 1050
      $('.animate_pc').not('#header').each(function(i){
        $(this).delay(i * 900).queue(function(next) {
          $(this).addClass('animate');
          next();
        });
      });
      <?php if(is_front_page()) { ?>
      var hSize = window.innerHeight - 70;
      $('#index_header_content').height(hSize);
      $('#index_slider .item .slice_image').height(hSize);
      var windowWidth = $(window).width();
      $(window).bind("resize orientationchange", function() {
        if ($(window).width() != windowWidth) {
          var hSize = window.innerHeight - 70;
          $('#index_header_content').height(hSize);
          $('#index_slider .item .slice_image').height(hSize);
          windowWidth = $(window).width();
        }
      });
      <?php }; ?>
    }
  }
  for (var i=0; i<mqls.length; i++){
    mediaqueryresponse(mqls[i])
    mqls[i].addListener(mediaqueryresponse)
  }

<?php }; ?>
<?php
     // work archive page script ----------------------------------------------
     function work_archive_script(){
       $options = get_design_plus_option();
?>
  var EffectH = 0;
  var scTop = $(window).scrollTop();
  var scBottom = scTop + $(window).height();
  var effectPos = scBottom - EffectH;
  $(".scroll_effect").each(function () {
    var thisPos = $(this).offset().top;
    if ( thisPos < effectPos ) {
      $(this).addClass("no_animate");
    }
  });
  $(".work_area").each(function() {
    var num = 1;
    $('.scroll_effect',this).each(function (i) {
      if( ! $(this).hasClass('no_animate') ) {
        $(this).addClass("animation_item"+num);
        num++;
      }
    });
  });
  $(window).on('scroll load', function(i) {
    var scTop = $(this).scrollTop();
    var scBottom = scTop + $(this).height();
    var effectPos = scBottom - EffectH;
    $('.scroll_effect').not('.no_animate').each( function(i) {
      var thisPos = $(this).offset().top;
      if ( thisPos < effectPos ) {
        $(this).addClass('animate');
      }
    });
  });

<?php }; ?>
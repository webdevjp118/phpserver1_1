<?php

// カテゴリー編集用入力欄を出力 -------------------------------------------------------
function area_edit_extra_fields( $term ) {
	$term_meta = get_option( 'taxonomy_' . $term->term_id, array() );
	$term_meta = array_merge( array(
		'color' => '#a33f37',
		'color_hover' => '#d45348'
	), $term_meta );
?>
<tr class="form-field">
	<th colspan="2">

<div class="custom_category_meta">
 <h3 class="ccm_headline"><?php _e( 'Additional data', 'tcd-w' ); ?></h3>

 <div class="ccm_content clearfix">
  <h4 class="headline"><?php _e( 'Category color', 'tcd-w' ); ?></h4>
  <div class="input_field">
   <input type="text" name="term_meta[color]" value="<?php echo esc_attr( $term_meta['color'] ); ?>" data-default-color="#a33f37" class="c-color-picker"></p>
  </div><!-- END input_field -->
  <h4 class="headline"><?php _e( 'Category color on mouseover', 'tcd-w' ); ?></h4>
  <div class="input_field">
   <input type="text" name="term_meta[color_hover]" value="<?php echo esc_attr( $term_meta['color_hover'] ); ?>" data-default-color="#d45348" class="c-color-picker"></p>
  </div><!-- END input_field -->
 </div><!-- END ccm_content -->

</div><!-- END .custom_category_meta -->

 </th>
</tr><!-- END .form-field -->
<?php
}
add_action( 'area_edit_form_fields', 'area_edit_extra_fields' );


// データを保存 -------------------------------------------------------
function area_save_extra_fileds( $term_id ) {
	if ( isset( $_POST['term_meta'] ) ) {
		$term_meta = get_option( "taxonomy_{$term_id}", array() );
		$meta_keys = array(
			'color','color_hover'
		);
		foreach ( $meta_keys as $key ) {
			if ( isset( $_POST['term_meta'][$key] ) ) {
				$term_meta[$key] = $_POST['term_meta'][$key];
			}
		}

		update_option( "taxonomy_{$term_id}", $term_meta );
	}
}
add_action( 'edited_area', 'area_save_extra_fileds' );


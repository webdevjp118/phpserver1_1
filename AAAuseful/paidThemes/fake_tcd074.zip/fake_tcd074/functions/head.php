<?php
     function tcd_head() {
       $options = get_design_plus_option();
?>

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/design-plus.css?ver=<?php echo version_num(); ?>">
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/sns-botton.css?ver=<?php echo version_num(); ?>">
<link rel="stylesheet" media="screen and (max-width:1050px)" href="<?php echo get_template_directory_uri(); ?>/css/responsive.css?ver=<?php echo version_num(); ?>">
<link rel="stylesheet" media="screen and (max-width:1050px)" href="<?php echo get_template_directory_uri(); ?>/css/footer-bar.css?ver=<?php echo version_num(); ?>">

<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.easing.1.3.js?ver=<?php echo version_num(); ?>"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/jscript.js?ver=<?php echo version_num(); ?>"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/comment.js?ver=<?php echo version_num(); ?>"></script>

<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/js/simplebar.css?ver=<?php echo version_num(); ?>">
<script src="<?php echo get_template_directory_uri(); ?>/js/simplebar.min.js?ver=<?php echo version_num(); ?>"></script>

<?php if(is_mobile()) { ?>
<script src="<?php echo get_template_directory_uri(); ?>/js/footer-bar.js?ver=<?php echo version_num(); ?>"></script>
<?php }; ?>

<?php
     if($options['header_fix'] == 'type2') {
?>
<script src="<?php echo get_template_directory_uri(); ?>/js/header_fix.js?ver=<?php echo version_num(); ?>"></script>
<?php }; ?>
<?php
     if($options['mobile_header_fix'] == 'type2') {
?>
<script src="<?php echo get_template_directory_uri(); ?>/js/header_fix_mobile.js?ver=<?php echo version_num(); ?>"></script>
<?php };  ?>
<?php
     // Googleマップ
     if(is_page_template('page-design1.php')) {
       global $post;
       $access_address = get_post_meta($post->ID, 'access_address', true);
       if(!empty($access_address)){
?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr( $options['gmap_api_key'] ); ?>" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/pagebuilder/assets/js/googlemap.js?ver=<?php echo version_num(); ?>"></script>
<?php }; }; ?>

<style type="text/css">
<?php
     // フォントタイプの設定　------------------------------------------------------------------
?>

<?php
     // 基本のフォントタイプ
     if($options['font_type'] == 'type1') {
?>
body, input, textarea { font-family: Arial, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", "メイリオ", Meiryo, sans-serif; }
<?php } elseif($options['font_type'] == 'type2') { ?>
body, input, textarea { font-family: "Hiragino Sans", "ヒラギノ角ゴ ProN", "Hiragino Kaku Gothic ProN", "游ゴシック", YuGothic, "メイリオ", Meiryo, sans-serif; }
<?php } else { ?>
body, input, textarea { font-family: "Times New Roman" , "游明朝" , "Yu Mincho" , "游明朝体" , "YuMincho" , "ヒラギノ明朝 Pro W3" , "Hiragino Mincho Pro" , "HiraMinProN-W3" , "HGS明朝E" , "ＭＳ Ｐ明朝" , "MS PMincho" , serif; }
<?php }; ?>

<?php
     // 見出しのフォントタイプ
     if($options['headline_font_type'] == 'type1') {
?>
.rich_font, .p-vertical { font-family: Arial, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", "メイリオ", Meiryo, sans-serif; }
<?php } elseif($options['headline_font_type'] == 'type2') { ?>
.rich_font, .p-vertical { font-family: "Hiragino Sans", "ヒラギノ角ゴ ProN", "Hiragino Kaku Gothic ProN", "游ゴシック", YuGothic, "メイリオ", Meiryo, sans-serif; font-weight:500; }
<?php } else { ?>
.rich_font, .p-vertical { font-family: "Times New Roman" , "游明朝" , "Yu Mincho" , "游明朝体" , "YuMincho" , "ヒラギノ明朝 Pro W3" , "Hiragino Mincho Pro" , "HiraMinProN-W3" , "HGS明朝E" , "ＭＳ Ｐ明朝" , "MS PMincho" , serif; font-weight:500; }
<?php }; ?>

.rich_font_type1 { font-family: Arial, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", "メイリオ", Meiryo, sans-serif; }
.rich_font_type2 { font-family: "Hiragino Sans", "ヒラギノ角ゴ ProN", "Hiragino Kaku Gothic ProN", "游ゴシック", YuGothic, "メイリオ", Meiryo, sans-serif; font-weight:500; }
.rich_font_type3 { font-family: "Times New Roman" , "游明朝" , "Yu Mincho" , "游明朝体" , "YuMincho" , "ヒラギノ明朝 Pro W3" , "Hiragino Mincho Pro" , "HiraMinProN-W3" , "HGS明朝E" , "ＭＳ Ｐ明朝" , "MS PMincho" , serif; font-weight:500; }

<?php
     // 本文のフォントタイプ
     if(is_single()) {
       if($options['content_font_type'] == 'type1') {
?>
.post_content, #next_prev_post { font-family: Arial, "ヒラギノ角ゴ ProN W3", "Hiragino Kaku Gothic ProN", "メイリオ", Meiryo, sans-serif; }
<?php } elseif($options['content_font_type'] == 'type2') { ?>
.post_content, #next_prev_post { font-family: "Hiragino Sans", "ヒラギノ角ゴ ProN", "Hiragino Kaku Gothic ProN", "游ゴシック", YuGothic, "メイリオ", Meiryo, sans-serif; }
<?php } else { ?>
.post_content, #next_prev_post { font-family: "Times New Roman" , "游明朝" , "Yu Mincho" , "游明朝体" , "YuMincho" , "ヒラギノ明朝 Pro W3" , "Hiragino Mincho Pro" , "HiraMinProN-W3" , "HGS明朝E" , "ＭＳ Ｐ明朝" , "MS PMincho" , serif; }
<?php }; }; ?>

<?php
     //ヘッダー -----------------------------------------------------------------------------------

     $header_font_color = $options['header_font_color'];

     $header_font_color_hover = hex2rgb($options['header_font_color_hover']);
     $header_font_color_hover = implode(",",$header_font_color_hover);

     $header_bg_color = hex2rgb($options['fix_header_bg_color']);
     $header_bg_color = implode(",",$header_bg_color);
?>
#header, #header a, #menu_button:before { color:<?php echo esc_html($header_font_color); ?>; }
#header a:hover, #menu_button:hover:before { color:rgba(<?php echo esc_html($header_font_color_hover); ?>,<?php echo esc_html($options['header_font_color_hover_opacity']); ?>); }
#header.active, .header_fix #header, .header_fix_mobile #header {
  color:<?php echo esc_html($options['fix_header_font_color']); ?>;
  background:rgba(<?php echo esc_html($header_bg_color); ?>,<?php echo esc_html($options['fix_header_bg_color_opacity']); ?>);
}
#header.active a, .header_fix #header a, .header_fix_mobile #header a, .header_fix_mobile #menu_button:before { color:<?php echo esc_html($options['fix_header_font_color']); ?>; }
#header.active a:hover, .header_fix #header a:hover, .header_fix_mobile #header a:hover, .header_fix_mobile #menu_button:hover:before { color:<?php echo esc_html($options['fix_header_font_color_hover']); ?>; }
@media screen and (max-width:1050px) {
  #header {
    color:<?php echo esc_html($options['fix_header_font_color']); ?>;
    background:rgba(<?php echo esc_html($header_bg_color); ?>,<?php echo esc_html($options['fix_header_bg_color_opacity']); ?>);
  }
  #header a, #menu_button:before { color:<?php echo esc_html($options['fix_header_font_color']); ?>; }
  #header a:hover, #menu_button:hover:before { color:<?php echo esc_html($options['fix_header_font_color_hover']); ?>; }
}

<?php
     // グローバルメニュー
?>
#global_menu > ul > li > a { color:<?php echo esc_html($header_font_color); ?>; }
#global_menu > ul > li > a:hover { color:rgba(<?php echo esc_html($header_font_color_hover); ?>,<?php echo esc_html($options['header_font_color_hover_opacity']); ?>); }
#global_menu > ul > li a.active, #global_menu > ul > li.active_button > a { color:<?php echo esc_html($options['fix_header_font_color_hover']); ?>; }
#global_menu ul ul a { color:<?php echo esc_html($options['global_menu_child_font_color']); ?> !important; background:<?php echo esc_html($options['global_menu_child_bg_color']); ?>; }
#global_menu ul ul a:hover { background:<?php echo esc_html($options['global_menu_child_bg_color_hover']); ?>; }

<?php
     // ドロワーメニュー
?>
#drawer_menu { background:<?php echo esc_html($options['mobile_menu_bg_color']); ?>; }
#mobile_menu a { color:<?php echo esc_html($options['mobile_menu_font_color']); ?>; background:<?php echo esc_html($options['mobile_menu_bg_color']); ?>; border-bottom:1px solid <?php echo esc_html($options['mobile_menu_border_color']); ?>; }
#mobile_menu li li a { background:<?php echo esc_html($options['mobile_menu_sub_menu_bg_color']); ?>; }
#mobile_menu a:hover, #drawer_menu .close_button:hover, #mobile_menu .child_menu_button:hover { color:<?php echo esc_html($options['mobile_menu_font_hover_color']); ?>; background:<?php echo esc_html($options['mobile_menu_bg_hover_color']); ?>; }

<?php
     // メガメニュー
     $mega_menu_overlay_color = hex2rgb($options['mega_menu_overlay_color']);
     $mega_menu_overlay_color = implode(",",$mega_menu_overlay_color);
?>
.megamenu_blog_list { background:<?php echo esc_html($options['mega_menu_bg_color']); ?>; }
.megamenu_blog_list_inner { border-color:rgba(255,255,255,0.3); }
.megamenu_blog_list .menu_area a, .megamenu_blog_list .menu_area a:hover, .megamenu_blog_list .menu_area li.active a, .megamenu_blog_list .post_list li .title { color:<?php echo esc_html($options['mega_menu_font_color']); ?> !important; }
.megamenu_blog_list .menu_area a:hover, .megamenu_blog_list .menu_area li.active a, .megamenu_blog_list .post_list { background:<?php echo esc_html($options['mega_menu_category_color']); ?>; }
.megamenu_blog_list .post_list li .overlay {
  background: -webkit-linear-gradient(top, transparent, rgba(<?php echo esc_html($mega_menu_overlay_color); ?>,<?php echo esc_html($options['mega_menu_overlay_opacity']); ?>));
  background: linear-gradient(to bottom, transparent, rgba(<?php echo esc_html($mega_menu_overlay_color); ?>,<?php echo esc_html($options['mega_menu_overlay_opacity']); ?>));
}
<?php
     // フッター -----------------------------------------------------------------------------------

     // バナー一覧
     if( $options['show_footer_banner1'] || $options['show_footer_banner2'] || $options['show_footer_banner3'] || $options['show_footer_banner4'] ) {
       for ( $i = 1; $i <= 4; $i++ ) :
?>
#footer_banner .item<?php echo $i; ?> a { color:<?php echo esc_html($options['footer_banner_font_color'.$i]); ?> !important; }
#footer_banner .item<?php echo $i; ?> .title { font-size:<?php echo esc_html($options['footer_banner_title_font_size'.$i]); ?>px; }
#footer_banner .item<?php echo $i; ?> .desc { font-size:<?php echo esc_html($options['footer_banner_desc_font_size'.$i]); ?>px; }
<?php
     if($options['footer_banner_use_overlay'.$i]){
       $footer_banner_overlay_color = hex2rgb($options['footer_banner_overlay_color'.$i]);
       $footer_banner_overlay_color = implode(",",$footer_banner_overlay_color);
?>
#footer_banner .item<?php echo $i; ?> .overlay { background:rgba(<?php echo esc_html($footer_banner_overlay_color); ?>,<?php echo esc_html($options['footer_banner_overlay_opacity'.$i]); ?>); }
<?php }; ?>
@media screen and (max-width:650px) {
  #footer_banner .item<?php echo $i; ?> .title { font-size:<?php echo esc_html($options['footer_banner_title_font_size_mobile'.$i]); ?>px; }
  #footer_banner .item<?php echo $i; ?> .desc { font-size:<?php echo esc_html($options['footer_banner_desc_font_size_mobile'.$i]); ?>px; }
}
<?php
       endfor;
     }

     // フッターボタン
     if( ( is_mobile() && $options['show_footer_button1']) || ( is_mobile() && $options['show_footer_button2']) ) {
?>
#footer_button .button1 a { color:<?php echo esc_html($options['footer_button_font_color1']); ?>; background:<?php echo esc_html($options['footer_button_bg_color1']); ?>; }
#footer_button .button1 a:hover { color:<?php echo esc_html($options['footer_button_font_color_hover1']); ?>; background:<?php echo esc_html($options['footer_button_bg_color_hover1']); ?>; }
#footer_button .button2 a { color:<?php echo esc_html($options['footer_button_font_color2']); ?>; background:<?php echo esc_html($options['footer_button_bg_color2']); ?>; }
#footer_button .button2 a:hover { color:<?php echo esc_html($options['footer_button_font_color_hover2']); ?>; background:<?php echo esc_html($options['footer_button_bg_color_hover2']); ?>; }
<?php
     };
     // 実績一覧 ---------------------------------------------------------------------------
     $work_list_category_bg_color = hex2rgb($options['work_list_category_bg_color']);
     $work_list_category_bg_color = implode(",",$work_list_category_bg_color);
?>
.work_list .item .title { font-size:<?php echo esc_html($options['work_list_title_font_size']); ?>px; }
.work_list .category {
  font-size:<?php echo esc_html($options['work_list_category_font_size']); ?>px; color:<?php echo esc_html($options['work_list_category_font_color']); ?>;
  background: -webkit-linear-gradient(top, transparent, rgba(<?php echo esc_html($work_list_category_bg_color); ?>,<?php echo esc_html($options['work_list_caetgory_opacity']); ?>));
  background: linear-gradient(to bottom, transparent, rgba(<?php echo esc_html($work_list_category_bg_color); ?>,<?php echo esc_html($options['work_list_caetgory_opacity']); ?>));
}
@media screen and (max-width:650px) {
  .work_list .item .title { font-size:<?php echo esc_html($options['work_list_title_font_size_mobile']); ?>px; }
  .work_list .category { font-size:<?php echo esc_html($options['work_list_category_font_size_mobile']); ?>px; }
}
<?php
     // ブログ -----------------------------------------------------------------------------
     if(is_archive() || is_home() || is_search() || is_single() ) {
       $archive_blog_bg_color = hex2rgb($options['archive_blog_bg_color']);
       $archive_blog_bg_color = implode(",",$archive_blog_bg_color);
?>
body.single .post_content { font-size:<?php echo esc_html($options['single_blog_content_font_size']); ?>px; }
#page_header_catch .catch { font-size:<?php echo esc_html($options['blog_catch_font_size']); ?>px; color:<?php echo esc_html($options['blog_catch_color']); ?>; }
#page_header_catch .desc { font-size:<?php echo esc_html($options['blog_desc_font_size']); ?>px; color:<?php echo esc_html($options['blog_desc_color']); ?>; }
#tab_button_list li span { font-size:<?php echo esc_attr($options['archive_blog_tab_font_size']); ?>px; }
#archive_catch h2 { font-size:<?php echo esc_attr($options['archive_blog_headline_font_size']); ?>px; }
#blog_list .title { font-size:<?php echo esc_html($options['archive_blog_title_font_size']); ?>px; }
#blog_list .excerpt { font-size:<?php echo esc_html($options['archive_blog_desc_font_size']); ?>px; }
#blog_list a .title_area { color:<?php echo esc_html($options['archive_blog_title_color']); ?> !important; }
#blog_list a:hover .title_area { color:<?php echo esc_html($options['archive_blog_title_color_hover']); ?> !important; }
#blog_list .category a, #single_category a { color:<?php echo esc_html($options['blog_category_font_color']); ?>; background:<?php echo esc_html($options['blog_category_bg_color']); ?>; }
#blog_list .category a:hover, #single_category a:hover { color:<?php echo esc_html($options['blog_category_font_color_hover']); ?>; background:<?php echo esc_html($options['blog_category_bg_color_hover']); ?>; }
#blog_list .overlay {
  background: -webkit-linear-gradient(top, transparent, rgba(<?php echo esc_html($archive_blog_bg_color); ?>,<?php echo esc_html($options['archive_blog_bg_opacity']); ?>));
  background: linear-gradient(to bottom, transparent, rgba(<?php echo esc_html($archive_blog_bg_color); ?>,<?php echo esc_html($options['archive_blog_bg_opacity']); ?>));
}
#post_title_area .title { font-size:<?php echo esc_html($options['single_blog_title_font_size']); ?>px; }
@media screen and (max-width:650px) {
  body.single .post_content { font-size:<?php echo esc_html($options['single_blog_content_font_size_mobile']); ?>px; }
  #page_header_catch .catch { font-size:<?php echo esc_html($options['blog_catch_font_size_mobile']); ?>px; }
  #page_header_catch .desc { font-size:<?php echo esc_html($options['blog_desc_font_size_mobile']); ?>px; }
  #tab_button_list li span { font-size:<?php echo esc_attr($options['archive_blog_tab_font_size_mobile']); ?>px; }
  #archive_catch h2 { font-size:<?php echo esc_attr($options['archive_blog_headline_font_size_mobile']); ?>px; }
  #blog_list .title { font-size:<?php echo esc_html($options['archive_blog_title_font_size_mobile']); ?>px; }
  #blog_list .excerpt { font-size:<?php echo esc_html($options['archive_blog_desc_font_size_mobile']); ?>px; }
  #post_title_area .title { font-size:<?php echo esc_html($options['single_blog_title_font_size_mobile']); ?>px; }
  #related_post .headline { font-size:<?php echo esc_html($options['related_headline_font_size_mobile']); ?>px; }
}
<?php
     }
     // トップページ -----------------------------------------------------------------------------
     if(is_front_page()) {
       // 画像スライダー
       if($options['index_header_content_type'] == 'type1') {
         for($i=1; $i<= 3; $i++):
           $use_text_shadow = $options['index_slider_use_shadow'.$i];
           if($use_text_shadow) {
             $shadow1 = $options['index_slider_shadow_h'.$i];
             $shadow2 = $options['index_slider_shadow_v'.$i];
             $shadow3 = $options['index_slider_shadow_b'.$i];
             $shadow4 = $options['index_slider_shadow_c'.$i];
           };
           // キャッチフレーズ、説明文
?>
#index_slider .item<?php echo $i; ?> .catch { font-size:<?php echo esc_html($options['index_slider_catch_font_size'.$i]); ?>px; color:<?php echo esc_html($options['index_slider_catch_color'.$i]); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
#index_slider .item<?php echo $i; ?> .desc { font-size:<?php echo esc_html($options['index_slider_desc_font_size'.$i]); ?>px; color:<?php echo esc_html($options['index_slider_desc_color'.$i]); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
@media screen and (max-width:650px) {
  #index_slider .item<?php echo $i; ?> .catch { font-size:<?php echo esc_html($options['index_slider_catch_font_size_mobile'.$i]); ?>px; }
  #index_slider .item<?php echo $i; ?> .desc { font-size:<?php echo esc_html($options['index_slider_desc_font_size_mobile'.$i]); ?>px; }
}
<?php
     // ボタン
     if($options['index_slider_bottom_content_type'.$i] == 'type2') {
?>
#index_slider .item<?php echo $i; ?> .button { color:<?php echo esc_html($options['index_slider_button_font_color'.$i]); ?>; background:<?php echo esc_html($options['index_slider_button_bg_color'.$i]); ?>; }
#index_slider .item<?php echo $i; ?> .button:hover { color:<?php echo esc_html($options['index_slider_button_font_color_hover'.$i]); ?>; background:<?php echo esc_html($options['index_slider_button_bg_color_hover'.$i]); ?>; }
<?php
     // 検索フォーム
     } elseif($options['index_slider_bottom_content_type'.$i] == 'type3') {
?>
#index_slider .search_area { background:rgba(255,255,255,<?php echo esc_html($options['index_slider_search_opacity'.$i]); ?>); }
<?php
     };
     // オーバーレイ
     if($options['index_slider_use_overlay'.$i] || $options['index_slider_use_overlay_mobile'.$i]) {
       $overlay_color = hex2rgb($options['index_slider_overlay_color'.$i]);
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = $options['index_slider_overlay_opacity'.$i];
       if(is_mobile() && $options['index_slider_use_overlay_mobile'.$i]) {
         $overlay_color = hex2rgb($options['index_slider_overlay_color_mobile'.$i]);
         $overlay_color = implode(",",$overlay_color);
         $overlay_opacity = $options['index_slider_overlay_opacity_mobile'.$i];
       }
?>
#index_slider .item<?php echo $i; ?> .overlay { background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>); }
<?php
       };
     endfor;
       // 画像スライダー　スマホ用　テキストシャドウ
       if($options['index_slider_mobile_content_type'] == 'type3'){
         $use_text_shadow = $options['index_slider_mobile_use_shadow'];
         if($use_text_shadow) {
           $shadow1 = $options['index_slider_mobile_shadow_h'];
           $shadow2 = $options['index_slider_mobile_shadow_v'];
           $shadow3 = $options['index_slider_mobile_shadow_b'];
           $shadow4 = $options['index_slider_mobile_shadow_c'];
         }
?>
#index_slider .caption.mobile .catch { font-size:<?php echo esc_attr($options['index_slider_mobile_catch_font_size']); ?>px; color:<?php echo esc_attr($options['index_slider_mobile_catch_color']); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
<?php
       };
     }; // END 画像スライダー

      // 動画 ---------------------------------------------------------------------------------------------------------------------------------------
     if($options['index_header_content_type'] == 'type2' || $options['index_header_content_type'] == 'type3') {
       $use_text_shadow = $options['index_movie_use_shadow'];
       if($use_text_shadow) {
         $shadow1 = $options['index_movie_shadow_h'];
         $shadow2 = $options['index_movie_shadow_v'];
         $shadow3 = $options['index_movie_shadow_b'];
         $shadow4 = $options['index_movie_shadow_c'];
       };
?>
#index_slider .catch { font-size:<?php echo esc_html($options['index_movie_catch_font_size']); ?>px; color:<?php echo esc_html($options['index_movie_catch_color']); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
#index_slider .desc { font-size:<?php echo esc_html($options['index_movie_desc_font_size']); ?>px; color:<?php echo esc_html($options['index_movie_desc_color']); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
<?php
     // ボタン
     if($options['index_movie_bottom_content_type'] == 'type2') {
?>
#index_slider .button { color:<?php echo esc_html($options['index_movie_button_font_color']); ?>; background:<?php echo esc_html($options['index_movie_button_bg_color']); ?>; }
#index_slider .button:hover { color:<?php echo esc_html($options['index_movie_button_font_color_hover']); ?>; background:<?php echo esc_html($options['index_movie_button_bg_color_hover']); ?>; }
<?php
     // 検索フォーム
     } elseif($options['index_movie_bottom_content_type'] == 'type3') {
?>
#index_slider .search_area { background:rgba(255,255,255,<?php echo esc_html($options['index_movie_search_opacity']); ?>); }
<?php
     };
     // オーバーレイ
     if($options['index_movie_use_overlay'] || $options['index_movie_use_overlay']) {
       $overlay_color = hex2rgb($options['index_movie_overlay_color']);
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = $options['index_movie_overlay_opacity'];
?>
#index_slider .overlay { background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>); }
<?php }; ?>
@media screen and (max-width:650px) {
  #index_slider .catch { font-size:<?php echo esc_html($options['index_movie_catch_font_size_mobile']); ?>px; }
  #index_slider .desc { font-size:<?php echo esc_html($options['index_movie_desc_font_size_mobile']); ?>px; }
}
<?php
     // モバイルサイズ時に別のコンテンツを表示する場合 ---------------
     if($options['index_movie_mobile_content_type'] == 'type2') {
       $use_text_shadow = $options['index_movie_use_shadow_mobile'];
       if($use_text_shadow) {
         $shadow1 = $options['index_movie_shadow_h_mobile'];
         $shadow2 = $options['index_movie_shadow_v_mobile'];
         $shadow3 = $options['index_movie_shadow_b_mobile'];
         $shadow4 = $options['index_movie_shadow_c_mobile'];
       };
?>
@media screen and (max-width:650px) {
  <?php
       // ボタン
       if($options['index_movie_bottom_content_type_mobile'] == 'type2') {
  ?>
  #index_slider .button { color:<?php echo esc_html($options['index_movie_button_font_color_mobile']); ?>; background:<?php echo esc_html($options['index_movie_button_bg_color_mobile']); ?>; }
  #index_slider .button:hover { color:<?php echo esc_html($options['index_movie_button_font_color_hover_mobile']); ?>; background:<?php echo esc_html($options['index_movie_button_bg_color_hover_mobile']); ?>; }
  <?php
       // 検索フォーム
       } elseif($options['index_movie_bottom_content_type_mobile'] == 'type3') {
  ?>
  #index_slider .search_area { background:rgba(255,255,255,<?php echo esc_html($options['index_movie_search_opacity_mobile']); ?>); }
  <?php
       };
       // オーバーレイ
       if($options['index_movie_use_overlay_mobile'] || $options['index_movie_use_overlay_mobile']) {
         $overlay_color = hex2rgb($options['index_movie_overlay_color_mobile']);
         $overlay_color = implode(",",$overlay_color);
         $overlay_opacity = $options['index_movie_overlay_opacity_mobile'];
  ?>
  #index_slider .overlay { background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>); }
  <?php }; ?>
  #index_slider .catch { font-size:<?php echo esc_html($options['index_movie_mobile_catch_font_size']); ?>px; color:<?php echo esc_html($options['index_movie_catch_color_mobile']); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
  #index_slider .desc { font-size:<?php echo esc_html($options['index_movie_mobile_desc_font_size']); ?>px; color:<?php echo esc_html($options['index_movie_desc_color_mobile']); ?>; <?php if($use_text_shadow) { ?>text-shadow:<?php echo esc_attr($shadow1); ?>px <?php echo esc_attr($shadow2); ?>px <?php echo esc_attr($shadow3); ?>px <?php echo esc_attr($shadow4); ?>;<?php }; ?> }
}
<?php
       }; // END content type2
     }; // END 動画

     // ニュースティッカー ------------------------------------------------------------------------------------------------
     if($options['show_index_news']){
       $overlay_color = hex2rgb($options['index_news_bg_color']);
       $overlay_color = implode(",",$overlay_color);
?>
#index_news { background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($options['index_news_bg_opacity']); ?>); }
#index_news a { color:<?php echo esc_attr($options['index_news_font_color']); ?>; }
#index_news a:hover { color:<?php echo esc_attr($options['index_news_font_color_hover']); ?>; }
<?php
     };
     // コンテンツビルダー -------------------------------------------------------------------------------------------------------------
     if (!empty($options['contents_builder'])) :
       $content_count = 1;
       foreach($options['contents_builder'] as $content) :
         // コンテンツ１
         if ($content['cb_content_select'] == 'content1') {
?>
.index_content1.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['content1_catch_font_size']); ?>px; }
.index_content1.num<?php echo $content_count; ?> .desc { font-size:<?php echo esc_attr($content['content1_desc_font_size']); ?>px; }
.index_content1.num<?php echo $content_count; ?> .link_button a { color:<?php echo esc_attr($content['content1_button_font_color']); ?>; background:<?php echo esc_attr($content['content1_button_bg_color']); ?>; }
.index_content1.num<?php echo $content_count; ?> .link_button a:hover { color:<?php echo esc_attr($content['content1_button_font_color_hover']); ?>; background:<?php echo esc_attr($content['content1_button_bg_color_hover']); ?>; }
@media screen and (max-width:650px) {
  .index_content1.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['content1_catch_font_size_mobile']); ?>px; }
  .index_content1.num<?php echo $content_count; ?> .desc { font-size:<?php echo esc_attr($content['content1_desc_font_size_mobile']); ?>px; }
}
<?php
     // コンテンツ２
     } elseif ($content['cb_content_select'] == 'content2') {
       $content2_overlay_color = hex2rgb($content['content2_overlay_color']);
       $content2_overlay_color = implode(",",$content2_overlay_color);
?>
.index_content2.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['content2_catch_font_size']); ?>px; }
.index_content2.num<?php echo $content_count; ?> .desc { font-size:<?php echo esc_attr($content['content2_desc_font_size']); ?>px; }
.index_content2.num<?php echo $content_count; ?> .link_button a { color:<?php echo esc_attr($content['content2_button2_font_color']); ?>; background:<?php echo esc_attr($content['content2_button2_bg_color']); ?>; }
.index_content2.num<?php echo $content_count; ?> .link_button a:hover { color:<?php echo esc_attr($content['content2_button2_font_color_hover']); ?>; background:<?php echo esc_attr($content['content2_button2_bg_color_hover']); ?>; }
.index_content2.num<?php echo $content_count; ?> .image_content .catch { font-size:<?php echo esc_attr($content['content2_catch2_font_size']); ?>px; color:<?php echo esc_attr($content['content2_catch2_color']); ?>; }
.index_content2.num<?php echo $content_count; ?> .image_content .link_button a { color:<?php echo esc_attr($content['content2_button1_font_color']); ?>; background:<?php echo esc_attr($content['content2_button1_bg_color']); ?>; }
.index_content2.num<?php echo $content_count; ?> .image_content .link_button a:hover { color:<?php echo esc_attr($content['content2_button1_font_color_hover']); ?>; background:<?php echo esc_attr($content['content2_button1_bg_color_hover']); ?>; }
.index_content2.num<?php echo $content_count; ?> .image_content .overlay { background:rgba(<?php echo esc_html($content2_overlay_color); ?>,<?php echo esc_html($content['content2_overlay_opacity']); ?>); }
@media screen and (max-width:650px) {
  .index_content2.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['content2_catch_font_size_mobile']); ?>px; }
  .index_content2.num<?php echo $content_count; ?> .desc { font-size:<?php echo esc_attr($content['content2_desc_font_size_mobile']); ?>px; }
  .index_content2.num<?php echo $content_count; ?> .image_content .catch { font-size:<?php echo esc_attr($content['content2_catch2_font_size_mobile']); ?>px; }
}
<?php
     // パララックス
     } elseif ($content['cb_content_select'] == 'para_content') {
       $para_content_overlay_color = hex2rgb($content['para_content_overlay_color']);
       $para_content_overlay_color = implode(",",$para_content_overlay_color);
?>
.index_parallax.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['para_content_catch_font_size']); ?>px; }
.index_parallax.num<?php echo $content_count; ?> .desc { font-size:<?php echo esc_attr($content['para_content_desc_font_size']); ?>px; }
.index_parallax.num<?php echo $content_count; ?> .overlay { background:rgba(<?php echo esc_html($para_content_overlay_color); ?>,<?php echo esc_html($content['para_content_overlay_opacity']); ?>); }
@media screen and (max-width:650px) {
  .index_parallax.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['para_content_catch_font_size_mobile']); ?>px; }
  .index_parallax.num<?php echo $content_count; ?> .desc { font-size:<?php echo esc_attr($content['para_content_desc_font_size_mobile']); ?>px; }
}
<?php
     // 実績一覧
     } elseif ($content['cb_content_select'] == 'post_list') {
?>
.index_work_list.num<?php echo $content_count; ?> .link_button a { color:<?php echo esc_attr($content['post_list_button_font_color']); ?>; background:<?php echo esc_attr($content['post_list_button_bg_color']); ?>; }
.index_work_list.num<?php echo $content_count; ?> .link_button a:hover { color:<?php echo esc_attr($content['post_list_button_font_color_hover']); ?>; background:<?php echo esc_attr($content['post_list_button_bg_color_hover']); ?>; }
<?php
     // カルーセル
     } elseif ($content['cb_content_select'] == 'carousel') {
?>
.index_carousel.num<?php echo $content_count; ?> .caption { color:<?php echo esc_attr($content['carousel_catch_color']); ?>; }
.index_carousel.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['carousel_catch_font_size']); ?>px; }
.index_carousel.num<?php echo $content_count; ?> .title { font-size:<?php echo esc_attr($content['carousel_title_font_size']); ?>px; }
.index_carousel.num<?php echo $content_count; ?> .title span { font-size:<?php echo esc_attr($content['carousel_sub_title_font_size']); ?>px; }
@media screen and (max-width:650px) {
  .index_carousel.num<?php echo $content_count; ?> .catch { font-size:<?php echo esc_attr($content['carousel_catch_font_size_mobile']); ?>px; }
  .index_carousel.num<?php echo $content_count; ?> .title { font-size:<?php echo esc_attr($content['carousel_title_font_size_mobile']); ?>px; }
  .index_carousel.num<?php echo $content_count; ?> .title span { font-size:<?php echo esc_attr($content['carousel_sub_title_font_size_mobile']); ?>px; }
}
<?php
     for($i=1; $i<= 6; $i++):
       $carousel_overlay_color = hex2rgb($content['carousel_overlay_color'.$i]);
       $carousel_overlay_color = implode(",",$carousel_overlay_color);
?>
.index_carousel.num<?php echo $content_count; ?> .item<?php echo $i; ?> .overlay { background:rgba(<?php echo esc_html($carousel_overlay_color); ?>,<?php echo esc_html($content['carousel_overlay_opacity'.$i]); ?>); }
<?php
         endfor;
       }; // END カルーセル
       $content_count++;
       endforeach;
     endif; // END コンテンツビルダー

     // 実績アーカイブ -----------------------------------------------------------------------------
     } elseif(is_post_type_archive('work')) {
       $archive_work_tab_bg_color = hex2rgb($options['archive_work_tab_bg_color']);
       $archive_work_tab_bg_color = implode(",",$archive_work_tab_bg_color);
?>
#page_header_catch .catch { font-size:<?php echo esc_attr($options['work_catch_font_size']); ?>px; color:<?php echo esc_html($options['work_catch_color']); ?>; }
#page_header_catch .desc { font-size:<?php echo esc_attr($options['work_desc_font_size']); ?>px; color:<?php echo esc_html($options['work_desc_color']); ?>; }
.work_area_top .headline { font-size:<?php echo esc_attr($options['archive_work_headline_font_size']); ?>px; }
.work_area_top .desc { font-size:<?php echo esc_attr($options['archive_work_desc_font_size']); ?>px; }
#tab_button_list li a { font-size:<?php echo esc_attr($options['archive_work_tab_font_size']); ?>px; color:<?php echo esc_html($options['archive_work_tab_font_color']); ?>; background:rgba(<?php echo esc_html($archive_work_tab_bg_color); ?>,<?php echo esc_html($options['archive_work_tab_bg_opacity']); ?>); }
#tab_button_list li a:hover { color:<?php echo esc_html($options['archive_work_tab_font_color_hover']); ?>; background:<?php echo esc_html($options['archive_work_tab_bg_color_hover']); ?>; }
#tab_button_list li a.active { color:<?php echo esc_html($options['archive_work_tab_font_color_hover']); ?>; background:<?php echo esc_html($options['archive_work_tab_bg_color_active']); ?>; }
#blur_bg { filter:blur(<?php echo esc_attr($options['archive_work_tab_bg_blur']); ?>px); }
.work_area .child_category_list ul li a { font-size:<?php echo esc_attr($options['archive_work_button_font_size']); ?>px; background:<?php echo esc_html($options['archive_work_button_bg_color']); ?>; color:<?php echo esc_html($options['archive_work_button_font_color']); ?>; }
.work_area .child_category_list ul li a:hover, .work_area .child_category_list ul li a.active { background:<?php echo esc_html($options['archive_work_button_bg_color_hover']); ?>; color:<?php echo esc_html($options['archive_work_button_font_color_hover']); ?>; }
@media screen and (max-width:650px) {
  #page_header_catch .catch { font-size:<?php echo esc_attr($options['work_catch_font_size_mobile']); ?>px; }
  #page_header_catch .desc { font-size:<?php echo esc_attr($options['work_desc_font_size_mobile']); ?>px; }
  .work_area_top .headline { font-size:<?php echo esc_attr($options['archive_work_headline_font_size_mobile']); ?>px; }
  .work_area_top .desc { font-size:<?php echo esc_attr($options['archive_work_desc_font_size_mobile']); ?>px; }
  #tab_button_list li a { font-size:<?php echo esc_attr($options['archive_work_tab_font_size_mobile']); ?>px; }
  .work_area .child_category_list ul li a { font-size:<?php echo esc_attr($options['archive_work_button_font_size_mobile']); ?>px; }
}
<?php
     // 実績カテゴリー -----------------------------------------------------------------------------
     } elseif(is_tax('landmark') || is_tax('area')) {
?>
#archive_catch h2 { font-size:<?php echo esc_attr($options['archive_work_headline_font_size']); ?>px; }
#archive_desc p { font-size:<?php echo esc_attr($options['archive_work_desc_font_size']); ?>px; }
@media screen and (max-width:650px) {
  #archive_catch h2 { font-size:<?php echo esc_attr($options['archive_work_headline_font_size_mobile']); ?>px; }
  #archive_desc p { font-size:<?php echo esc_attr($options['archive_work_desc_font_size_mobile']); ?>px; }
}
<?php
     // 実績詳細ページ ----------------------------------------------------------------------------
     } elseif(is_singular('work')) {
       global $post;

       $area_category = get_the_terms( $post->ID, 'area' );
       $area_category_color = '#a33f37';
       $area_category_color_hover = '#d45348';
       if ( $area_category && ! is_wp_error($area_category) ) {
         foreach ( $area_category as $area_cat ) :
           $area_name = $area_cat->name;
           $area_id = $area_cat->term_id;
           $area_custom_fields = get_option( 'taxonomy_' . $area_id, array() );
           if (!empty($area_custom_fields['color'])){
             $area_category_color = $area_custom_fields['color'];
           }
           if (!empty($area_custom_fields['color_hover'])){
             $area_category_color_hover = $area_custom_fields['color_hover'];
           }
         endforeach;
       };
?>
#single_work_title_area .category li.parent a { color:<?php echo esc_html($options['work_category_font_color']); ?>; background:<?php echo esc_html($options['work_category_bg_color']); ?>; }
#single_work_title_area .category li.parent a:hover { color:<?php echo esc_html($options['work_category_font_color_hover']); ?>; background:<?php echo esc_html($options['work_category_bg_color_hover']); ?>; }
#single_work_title_area .category li.child a { background:<?php echo esc_html($area_category_color); ?>; }
#single_work_title_area .category li.child a:hover { background:<?php echo esc_html($area_category_color_hover); ?>; }
#single_work_title_area .title { font-size:<?php echo esc_attr($options['single_work_title_font_size']); ?>px; }
#article .post_content { font-size:<?php echo esc_attr($options['single_work_content_font_size']); ?>px; }
#related_work_list .headline { font-size:<?php echo esc_attr($options['related_work_headline_font_size']); ?>px; }
<?php
        // Contents builder
        $work_contents_builder = get_post_meta( $post->ID, 'work_contents_builder', true );
        if ( $work_contents_builder && is_array( $work_contents_builder ) ) :
          foreach( $work_contents_builder as $key => $content ) :
            if ( empty( $content['content_select'] ) || empty( $content['display'] ) ) continue;

            if ( ! empty( $content['catch'] ) ) :
?>
.work_content_<?php echo esc_attr( $key + 1 ); ?> .single_work_catch { color:<?php echo esc_html( $content['catch_color'] ); ?>; font-size:<?php echo esc_html( $content['catch_font_size'] ); ?>px; }
<?php
            endif;
            if ( ! empty( $content['show_button'] ) && ! empty( $content['button_label'] ) ) :
?>
.work_content_<?php echo esc_attr( $key + 1 ); ?> .work_data_list .link_button a { color:<?php echo esc_html( $content['button_font_color'] ); ?>; background:<?php echo esc_html( $content['button_bg_color'] ); ?>; }
.work_content_<?php echo esc_attr( $key + 1 ); ?> .work_data_list .link_button a:hover { color:<?php echo esc_html( $content['button_font_color_hover'] ); ?>; background:<?php echo esc_html( $content['button_bg_color_hover'] ); ?>; }
<?php
            endif;
          endforeach;
        endif;
?>
@media screen and (max-width:650px) {
  #single_work_title_area .title { font-size:<?php echo esc_attr($options['single_work_title_font_size_mobile']); ?>px; }
  #article .post_content { font-size:<?php echo esc_attr($options['single_work_content_font_size_mobile']); ?>px; }
  #related_work_list .headline { font-size:<?php echo esc_attr($options['related_work_headline_font_size_mobile']); ?>px; }
<?php
        if ( $work_contents_builder && is_array( $work_contents_builder ) ) :
          foreach( $work_contents_builder as $key => $content ) :
            if ( empty( $content['content_select'] ) || empty( $content['display'] ) ) continue;

            if ( ! empty( $content['catch'] ) ) :
?>
.work_content_<?php echo esc_attr( $key + 1 ); ?> .single_work_catch { font-size:<?php echo esc_html( $content['catch_font_size_mobile'] ); ?>px; }
<?php
            endif;
          endforeach;
        endif;
?>
}
<?php
     // 固定ページ -----------------------------------------------------------------------------
     } elseif(is_page()) {
       global $post;
       $title_font_size = '50';
       $title_font_size_mobile = '30';
       $desc_font_size = '16';
       $desc_font_size_mobile = '13';
       $title_font_size = get_post_meta($post->ID, 'page_title_font_size', true);
       $title_font_size_mobile = get_post_meta($post->ID, 'page_title_font_size_mobile', true);
       $desc_font_size = get_post_meta($post->ID, 'page_sub_title_font_size', true);
       $desc_font_size_mobile = get_post_meta($post->ID, 'page_sub_title_font_size_mobile', true);
?>
#page_header .catch { font-size:<?php echo esc_html($title_font_size); ?>px; }
#page_header .desc { font-size:<?php echo esc_html($desc_font_size); ?>px; }
body.page .post_content { font-size:<?php echo esc_html($options['single_blog_content_font_size']); ?>px; }
@media screen and (max-width:650px) {
  #page_header .catch { font-size:<?php echo esc_html($title_font_size_mobile); ?>px; }
  #page_header .desc { font-size:<?php echo esc_html($desc_font_size_mobile); ?>px; }
  body.page .post_content { font-size:<?php echo esc_html($options['single_blog_content_font_size_mobile']); ?>px; }
}
<?php
     // デザインページ　共通 ---------------------------------------------------------------------
     if(is_page_template('page-design1.php') || is_page_template('page-design2.php') || is_page_template('page-design3.php')) {
       global $post;
       $tab_font_color = get_post_meta($post->ID, 'tab_font_color', true);
       $tab_bg_color = get_post_meta($post->ID, 'tab_bg_color', true);
       $tab_font_color_hover = get_post_meta($post->ID, 'tab_font_color_hover', true);
       $tab_bg_color_hover = get_post_meta($post->ID, 'tab_bg_color_hover', true);
       $tab_bg_color_active = get_post_meta($post->ID, 'tab_bg_color_active', true);
       $tab_bg_opacity = get_post_meta($post->ID, 'tab_bg_opacity', true);
       $tab_font_size = get_post_meta($post->ID, 'tab_font_size', true);
       $tab_font_size_mobile = get_post_meta($post->ID, 'tab_font_size_mobile', true);
       $tab_bg_color = hex2rgb($tab_bg_color);
       $tab_bg_color = implode(",",$tab_bg_color);
?>
#tab_button_list li a { font-size:<?php echo esc_attr($tab_font_size); ?>px; color:<?php echo esc_html($tab_font_color); ?>; background:rgba(<?php echo esc_html($tab_bg_color); ?>,<?php echo esc_html($tab_bg_opacity); ?>); }
#tab_button_list li a:hover { color:<?php echo esc_html($tab_font_color_hover); ?>; background:<?php echo esc_html($tab_bg_color_hover); ?>; }
#tab_button_list li a.active { color:<?php echo esc_html($tab_font_color_hover); ?>; background:<?php echo esc_html($tab_bg_color_active); ?>; }
@media screen and (max-width:650px) {
  #tab_button_list li a { font-size:<?php echo esc_attr($tab_font_size_mobile); ?>px; }
}
<?php
     }
     // デザインページＡ --------------------------------------------------------------------
     if(is_page_template('page-design1.php')) {
       global $post;
       $design1_content1_catch_font_size = get_post_meta($post->ID, 'design1_content1_catch_font_size', true);
       $design1_content1_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content1_catch_font_size_mobile', true);
       $design1_content1_ic_catch_font_size = get_post_meta($post->ID, 'design1_content1_ic_catch_font_size', true);
       $design1_content1_ic_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content1_ic_catch_font_size_mobile', true);
       $design1_content1_ic_title_font_size = get_post_meta($post->ID, 'design1_content1_ic_title_font_size', true);
       $design1_content1_ic_title_font_size_mobile = get_post_meta($post->ID, 'design1_content1_ic_title_font_size_mobile', true);
       $design1_content1_ic_sub_title_font_size = get_post_meta($post->ID, 'design1_content1_ic_sub_title_font_size', true);
       $design1_content1_ic_sub_title_font_size_mobile = get_post_meta($post->ID, 'design1_content1_ic_sub_title_font_size_mobile', true);
       $design1_content2_catch_font_size = get_post_meta($post->ID, 'design1_content2_catch_font_size', true);
       $design1_content2_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content2_catch_font_size_mobile', true);
       $design1_content2_data_list = get_post_meta($post->ID, 'design1_content2_data_list', true);
       $design1_content2_ic_catch_font_size = get_post_meta($post->ID, 'design1_content2_ic_catch_font_size', true);
       $design1_content2_ic_catch_font_size_mobile = get_post_meta($post->ID, 'design1_content2_ic_catch_font_size_mobile', true);
       $design1_content2_ic_title_font_size = get_post_meta($post->ID, 'design1_content2_ic_title_font_size', true);
       $design1_content2_ic_title_font_size_mobile = get_post_meta($post->ID, 'design1_content2_ic_title_font_size_mobile', true);
       $design1_content2_ic_sub_title_font_size = get_post_meta($post->ID, 'design1_content2_ic_sub_title_font_size', true);
       $design1_content2_ic_sub_title_font_size_mobile = get_post_meta($post->ID, 'design1_content2_ic_sub_title_font_size_mobile', true);
       $design1_content3_headline_font_size = get_post_meta($post->ID, 'design1_content3_headline_font_size', true);
       $design1_content3_headline_font_size_mobile = get_post_meta($post->ID, 'design1_content3_headline_font_size_mobile', true);
       $design1_content4_headline_font_size = get_post_meta($post->ID, 'design1_content4_headline_font_size', true);
       $design1_content4_headline_font_size_mobile = get_post_meta($post->ID, 'design1_content4_headline_font_size_mobile', true);
       $access_button_font_color = get_post_meta($post->ID, 'access_button_font_color', true);
       $access_button_bg_color = get_post_meta($post->ID, 'access_button_bg_color', true);
       $access_button_font_color_hover = get_post_meta($post->ID, 'access_button_font_color_hover', true);
       $access_button_bg_color_hover = get_post_meta($post->ID, 'access_button_bg_color_hover', true);
?>
#design_content_id1 .dc_content .catch { font-size:<?php echo esc_html($design1_content1_catch_font_size); ?>px; }
#design_content_id1 .dc_image_content .catch { font-size:<?php echo esc_html($design1_content1_ic_catch_font_size); ?>px; }
#design_content_id1 .dc_image_content .title { font-size:<?php echo esc_html($design1_content1_ic_title_font_size); ?>px; }
#design_content_id1 .dc_image_content .title span { font-size:<?php echo esc_html($design1_content1_ic_sub_title_font_size); ?>px; }
#design_content_id2 .dc_content .catch { font-size:<?php echo esc_html($design1_content2_catch_font_size); ?>px; }
<?php
     if($design1_content2_data_list){
       $i = 1; foreach ( $design1_content2_data_list as $key => $value ) :
?>
.dc_message_list .item<?php echo $i; ?> .catch { font-size:<?php echo esc_attr($value['font_size']); ?>px !important; }
<?php $i++; endforeach; }; ?>
#design_content_id2 .dc_image_content .catch { font-size:<?php echo esc_html($design1_content2_ic_catch_font_size); ?>px; }
#design_content_id2 .dc_image_content .title { font-size:<?php echo esc_html($design1_content2_ic_title_font_size); ?>px; }
#design_content_id2 .dc_image_content .title span { font-size:<?php echo esc_html($design1_content2_ic_sub_title_font_size); ?>px; }
.dc_data_list .catch { font-size:<?php echo esc_html($design1_content3_headline_font_size); ?>px; }
#access_info .catch { font-size:<?php echo esc_html($design1_content4_headline_font_size); ?>px; }
#access_data .link_button a { color:<?php echo esc_html($access_button_font_color); ?>; background:<?php echo esc_html($access_button_bg_color); ?>; }
#access_data .link_button a:hover { color:<?php echo esc_html($access_button_font_color_hover); ?>; background:<?php echo esc_html($access_button_bg_color_hover); ?>; }
#access_info .pb_googlemap_custom-overlay-inner { background:<?php echo esc_html($options['gmap_marker_bg']); ?>; color:<?php echo esc_html($options['gmap_marker_color']); ?>; }
#access_info .pb_googlemap_custom-overlay-inner::after { border-color:<?php echo esc_html($options['gmap_marker_bg']); ?> transparent transparent transparent; }
@media screen and (max-width:650px) {
  #design_content_id1 .dc_content .catch { font-size:<?php echo esc_html($design1_content1_catch_font_size_mobile); ?>px; }
  #design_content_id1 .dc_image_content .catch { font-size:<?php echo esc_html($design1_content1_ic_catch_font_size_mobile); ?>px; }
  #design_content_id1 .dc_image_content .title { font-size:<?php echo esc_html($design1_content1_ic_title_font_size_mobile); ?>px; }
  #design_content_id1 .dc_image_content .title span { font-size:<?php echo esc_html($design1_content1_ic_sub_title_font_size_mobile); ?>px; }
  #design_content_id2 .dc_content .catch { font-size:<?php echo esc_html($design1_content2_catch_font_size_mobile); ?>px; }
  <?php
       if($design1_content2_data_list){
         $i = 1; foreach ( $design1_content2_data_list as $key => $value ) :
  ?>
  .dc_message_list .item<?php echo $i; ?> .catch { font-size:<?php echo esc_attr($value['font_size_mobile']); ?>px !important; }
  <?php $i++; endforeach; }; ?>
  #design_content_id2 .dc_image_content .catch { font-size:<?php echo esc_html($design1_content2_ic_catch_font_size_mobile); ?>px; }
  #design_content_id2 .dc_image_content .title { font-size:<?php echo esc_html($design1_content2_ic_title_font_size_mobile); ?>px; }
  #design_content_id2 .dc_image_content .title span { font-size:<?php echo esc_html($design1_content2_ic_sub_title_font_size_mobile); ?>px; }
  .dc_data_list .catch { font-size:<?php echo esc_html($design1_content3_headline_font_size_mobile); ?>px; }
  #access_info .catch { font-size:<?php echo esc_html($design1_content4_headline_font_size_mobile); ?>px; }
}
<?php
     };
     // デザインページＢ --------------------------------------------------------------------
     if(is_page_template('page-design2.php')) {
       global $post;
       for($i = 1; $i <= 4; $i++):
         $design2_catch_font_size = get_post_meta($post->ID, 'design2_content' . $i . '_catch_font_size', true);
         $design2_sub_title_font_size = get_post_meta($post->ID, 'design2_content' . $i . '_sub_title_font_size', true);
         $design2_ic_catch_font_size = get_post_meta($post->ID, 'design2_content' . $i . '_ic_catch_font_size', true);
         $design2_ic_title_font_size = get_post_meta($post->ID, 'design2_content' . $i . '_ic_title_font_size', true);
         $design2_ic_sub_title_font_size = get_post_meta($post->ID, 'design2_content' . $i . '_ic_sub_title_font_size', true);
?>
#design_content_id<?php echo $i; ?> .dc_content .catch { font-size:<?php echo esc_html($design2_catch_font_size); ?>px; }
#design_content_id<?php echo $i; ?> .dc_content .sub_title { font-size:<?php echo esc_html($design2_sub_title_font_size); ?>px; }
#design_content_id<?php echo $i; ?> .dc_image_content .catch { font-size:<?php echo esc_html($design2_ic_catch_font_size); ?>px; }
#design_content_id<?php echo $i; ?> .dc_image_content .title { font-size:<?php echo esc_html($design2_ic_title_font_size); ?>px; }
#design_content_id<?php echo $i; ?> .dc_image_content .title span { font-size:<?php echo esc_html($design2_ic_sub_title_font_size); ?>px; }
<?php
       endfor;
       for($i = 1; $i <= 4; $i++):
         $design2_catch_font_size_mobile = get_post_meta($post->ID, 'design2_content' . $i . '_catch_font_size_mobile', true);
         $design2_sub_title_font_size_mobile = get_post_meta($post->ID, 'design2_content' . $i . '_sub_title_font_size_mobile', true);
         $design2_ic_catch_font_size_mobile = get_post_meta($post->ID, 'design2_content' . $i . '_ic_catch_font_size_mobile', true);
         $design2_ic_title_font_size_mobile = get_post_meta($post->ID, 'design2_content'. $i . '_ic_title_font_size_mobile', true);
         $design2_ic_sub_title_font_size_mobile = get_post_meta($post->ID, 'design2_content' . $i . '_ic_sub_title_font_size_mobile', true);
?>
@media screen and (max-width:650px) {
  #design_content_id<?php echo $i; ?> .dc_content .catch { font-size:<?php echo esc_html($design2_catch_font_size_mobile); ?>px; }
  #design_content_id<?php echo $i; ?> .dc_content .sub_title { font-size:<?php echo esc_html($design2_sub_title_font_size_mobile); ?>px; }
  #design_content_id<?php echo $i; ?> .dc_image_content .catch { font-size:<?php echo esc_html($design2_ic_catch_font_size_mobile); ?>px; }
  #design_content_id<?php echo $i; ?> .dc_image_content .title { font-size:<?php echo esc_html($design2_ic_title_font_size_mobile); ?>px; }
  #design_content_id<?php echo $i; ?> .dc_image_content .title span { font-size:<?php echo esc_html($design2_ic_sub_title_font_size_mobile); ?>px; }
}
<?php
       endfor;
     };
     // デザインページＣ --------------------------------------------------------------------
     if(is_page_template('page-design3.php')) {
       global $post;
       $design3_content1_catch_font_size = get_post_meta($post->ID, 'design3_content1_catch_font_size', true);
       $design3_content1_catch_font_size_mobile = get_post_meta($post->ID, 'design3_content1_catch_font_size_mobile', true);
       $design3_content1_catch2_font_size = get_post_meta($post->ID, 'design3_content1_catch2_font_size', true);
       $design3_content1_catch2_font_size = get_post_meta($post->ID, 'design3_content1_catch2_font_size', true);
       $design3_content1_ic_catch_font_size = get_post_meta($post->ID, 'design3_content1_ic_catch_font_size', true);
       $design3_content1_ic_catch_font_size_mobile = get_post_meta($post->ID, 'design3_content1_ic_catch_font_size_mobile', true);
       $design3_content1_ic_title_font_size = get_post_meta($post->ID, 'design3_content1_ic_title_font_size', true);
       $design3_content1_ic_title_font_size_mobile = get_post_meta($post->ID, 'design3_content1_ic_title_font_size_mobile', true);
       $design3_content1_ic_sub_title_font_size = get_post_meta($post->ID, 'design3_content1_ic_sub_title_font_size', true);
       $design3_content1_ic_sub_title_font_size_mobile = get_post_meta($post->ID, 'design3_content1_ic_sub_title_font_size_mobile', true);
       $design3_content2_headline_font_size = get_post_meta($post->ID, 'design3_content2_headline_font_size', true);
       $design3_content2_headline_font_size_mobile = get_post_meta($post->ID, 'design3_content2_headline_font_size_mobile', true);
       $design3_content2_button_font_color = get_post_meta($post->ID, 'design3_content2_button_font_color', true);
       $design3_content2_button_bg_color = get_post_meta($post->ID, 'design3_content2_button_bg_color', true);
       $design3_content2_button_font_color_hover = get_post_meta($post->ID, 'design3_content2_button_font_color_hover', true);
       $design3_content2_button_bg_color_hover = get_post_meta($post->ID, 'design3_content2_button_bg_color_hover', true);
?>
#design_content_id1 .dc_content .catch { font-size:<?php echo esc_html($design3_content1_catch_font_size); ?>px; }
#design_content_id1 .dc_content .catch2 { font-size:<?php echo esc_html($design3_content1_catch2_font_size); ?>px; }
#design_content_id1 .dc_image_content .catch { font-size:<?php echo esc_html($design3_content1_ic_catch_font_size); ?>px; }
#design_content_id1 .dc_image_content .title { font-size:<?php echo esc_html($design3_content1_ic_title_font_size); ?>px; }
#design_content_id1 .dc_image_content .title span { font-size:<?php echo esc_html($design3_content1_ic_sub_title_font_size); ?>px; }
.dc_data_list .catch { font-size:<?php echo esc_html($design3_content2_headline_font_size); ?>px; }
#design_content_id2 .link_button a { color:<?php echo esc_html($design3_content2_button_font_color); ?>; background:<?php echo esc_html($design3_content2_button_bg_color); ?>; }
#design_content_id2 .link_button a:hover { color:<?php echo esc_html($design3_content2_button_font_color_hover); ?>; background:<?php echo esc_html($design3_content2_button_bg_color_hover); ?>; }
@media screen and (max-width:650px) {
  #design_content_id1 .dc_content .catch { font-size:<?php echo esc_html($design3_content1_catch_font_size_mobile); ?>px; }
  #design_content_id1 .dc_content .catch2 { font-size:<?php echo esc_html($design3_content1_catch2_font_size_mobile); ?>px; }
  #design_content_id1 .dc_image_content .catch { font-size:<?php echo esc_html($design3_content1_ic_catch_font_size_mobile); ?>px; }
  #design_content_id1 .dc_image_content .title { font-size:<?php echo esc_html($design3_content1_ic_title_font_size_mobile); ?>px; }
  #design_content_id1 .dc_image_content .title span { font-size:<?php echo esc_html($design3_content1_ic_sub_title_font_size_mobile); ?>px; }
  .dc_data_list .catch { font-size:<?php echo esc_html($design3_content2_headline_font_size_mobile); ?>px; }
}
<?php }; // END デザインページ ?>
<?php
     // 404ページ -----------------------------------------------------------------------------
     } elseif( is_404()) {
       $title_font_size_pc = ( ! empty( $options['header_txt_size_404'] ) ) ? $options['header_txt_size_404'] : 38;
       $sub_title_font_size_pc = ( ! empty( $options['header_sub_txt_size_404'] ) ) ? $options['header_sub_txt_size_404'] : 16;
       $title_font_size_mobile = ( ! empty( $options['header_txt_size_404_mobile'] ) ) ? $options['header_txt_size_404_mobile'] : 28;
       $sub_title_font_size_mobile = ( ! empty( $options['header_sub_txt_size_404_mobile'] ) ) ? $options['header_sub_txt_size_404_mobile'] : 14;
?>
#page_header .catch { font-size:<?php echo esc_html($title_font_size_pc); ?>px; }
#page_header .desc { font-size:<?php echo esc_html($sub_title_font_size_pc); ?>px; }
@media screen and (max-width:650px) {
  #page_header .catch { font-size:<?php echo esc_html($title_font_size_mobile); ?>px; }
  #page_header .desc { font-size:<?php echo esc_html($sub_title_font_size_mobile); ?>px; }
}
<?php
     }; //END page setting
?>

<?php
     // サムネイルのアニメーション設定　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
     if($options['hover_type']!="type4"){

       // ズーム ------------------------------------------------------------------------------
       if($options['hover_type']=="type1"){
?>
.author_profile a.avatar img, .animate_image img, .animate_background .image {
  width:100%; height:auto;
  -webkit-transition: transform  0.75s ease;
  transition: transform  0.75s ease;
}
.author_profile a.avatar:hover img, .animate_image:hover img, .animate_background:hover .image {
  -webkit-transform: scale(<?php echo $options['hover1_zoom']; ?>);
  transform: scale(<?php echo $options['hover1_zoom']; ?>);
}


<?php
     // スライド ------------------------------------------------------------------------------
     } elseif($options['hover_type']=="type2"){
?>
.animate_image img, .animate_background .image {
  -webkit-width:calc(100% + 30px) !important; width:calc(100% + 30px) !important; height:auto; max-width:inherit !important; position:relative;
  <?php if($options['hover2_direct']=='type1'): ?>
  -webkit-transform: translate(-15px, 0px); -webkit-transition-property: opacity, translateX; -webkit-transition: 0.5s;
  transform: translate(-15px, 0px); transition-property: opacity, translateX; transition: 0.5s;
  <?php else: ?>
  -webkit-transform: translate(-15px, 0px); -webkit-transition-property: opacity, translateX; -webkit-transition: 0.5s;
  transform: translate(-15px, 0px); transition-property: opacity, translateX; transition: 0.5s;
  <?php endif; ?>
}
.animate_image:hover img, .animate_background:hover .image {
  opacity:<?php echo $options['hover2_opacity']; ?>;
  <?php if($options['hover2_direct']=='type1'): ?>
  -webkit-transform: translate(0px, 0px);
  transform: translate(0px, 0px);
  <?php else: ?>
  -webkit-transform: translate(-30px, 0px);
  transform: translate(-30px, 0px);
  <?php endif; ?>
}
.animate_image.square img {
  -webkit-width:calc(100% + 30px) !important; width:calc(100% + 30px) !important; height:auto; max-width:inherit !important; position:relative;
  <?php if($options['hover2_direct']=='type1'): ?>
  -webkit-transform: translate(-15px, -15px); -webkit-transition-property: opacity, translateX; -webkit-transition: 0.5s;
  transform: translate(-15px, -15px); transition-property: opacity, translateX; transition: 0.5s;
  <?php else: ?>
  -webkit-transform: translate(-15px, -15px); -webkit-transition-property: opacity, translateX; -webkit-transition: 0.5s;
  transform: translate(-15px, -15px); transition-property: opacity, translateX; transition: 0.5s;
  <?php endif; ?>
}
.animate_image.square:hover img {
  opacity:<?php echo $options['hover2_opacity']; ?>;
  <?php if($options['hover2_direct']=='type1'): ?>
  -webkit-transform: translate(0px, -15px);
  transform: translate(0px, -15px);
  <?php else: ?>
  -webkit-transform: translate(-30px, -15px);
  transform: translate(-30px, -15px);
  <?php endif; ?>
}
<?php
     // フェードアウト ------------------------------------------------------------------------------
     } elseif($options['hover_type']=="type3"){
?>
.author_profile a.avatar, .animate_image, .animate_background, .animate_background .image_wrap {
  background: <?php echo $options['hover3_bgcolor']; ?>;
}
.author_profile a.avatar img, .animate_image img, .animate_background .image {
  -webkit-transition-property: opacity; -webkit-transition: 0.5s;
  transition-property: opacity; transition: 0.5s;
}
.author_profile a.avatar:hover img, .animate_image:hover img, .animate_background:hover .image {
  opacity: <?php echo $options['hover3_opacity']; ?>;
}
<?php }; }; // アニメーションここまで ?>


<?php
     // 色関連のスタイル　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

     // メインカラー ----------------------------------
     $main_color = esc_html($options['main_color']);
?>
a { color:#000; }

#comment_headline, .tcd_category_list a:hover, .tcd_category_list .child_menu_button:hover, .side_headline, #faq_category li a:hover, #faq_category li.active a, #archive_service .bottom_area .sub_category li a:hover,
  #side_service_category_list a:hover, #side_service_category_list li.active > a, #side_faq_category_list a:hover, #side_faq_category_list li.active a, #side_staff_list a:hover, #side_staff_list li.active a, .cf_data_list li a:hover,
    #side_campaign_category_list a:hover, #side_campaign_category_list li.active a, #side_clinic_list a:hover, #side_clinic_list li.active a
{ color: <?php echo $main_color; ?>; }

#index_slider .search_button:hover input, #return_top a, #comment_tab li a:hover, #comment_tab li.active a, #comment_header #comment_closed p, #submit_comment:hover, #cancel_comment_reply a:hover, #p_readmore .button:hover,
  #wp-calendar td a:hover, #p_readmore .button, .page_navi span.current, .page_navi a:hover, #post_pagination p, #post_pagination a:hover, .c-pw__btn:hover
{ background-color: <?php echo $main_color; ?>; }

#guest_info input:focus, #comment_textarea textarea:focus, .c-pw__box-input:focus, .page_navi span.current, .page_navi a:hover, #post_pagination p, #post_pagination a:hover
{ border-color: <?php echo $main_color; ?>; }

#comment_tab li.active a:after, #comment_header #comment_closed p:after
{ border-color:<?php echo $main_color; ?> transparent transparent transparent; }


<?php
     // サブカラー ----------------------------------
     $sub_color = esc_html($options['sub_color']);
?>
#footer a:hover, .cardlink_title a:hover, #related_post .item a:hover, .comment a:hover, .comment_form_wrapper a:hover,
  #bread_crumb a:hover, #bread_crumb li.home a:hover:after, .author_profile a:hover, .author_profile .author_link li a:hover:before, #post_meta_bottom a:hover,
    #recent_news a.link:hover, #recent_news .link:hover:after, #recent_news li a:hover .title, #searchform .submit_button:hover:before, .styled_post_list1 a:hover .title_area, .styled_post_list1 a:hover .date, .p-dropdown__title:hover:after, .p-dropdown__list li a:hover
{ color: <?php echo esc_html($sub_color); ?>; }
#post_pagination a:hover, #p_readmore .button:hover, #return_top a:hover
{ background-color: <?php echo esc_html($sub_color); ?>; }
<?php
     // その他のカラー ----------------------------------
?>
.post_content a { color: <?php echo esc_html($options['content_link_color']); ?>; }
.post_content a:hover { color:<?php echo esc_html($options['content_link_hover_color']); ?>; }
<?php
     // その他のスタイル ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

     // ロード画面 -----------------------------------------
     get_template_part('functions/loader');
     if($options['load_icon'] == 'type4'){
?>
#site_loader_logo_inner p { font-size:<?php echo esc_html($options['load_type4_catch_font_size']); ?>px; color:<?php echo esc_html($options['load_type4_catch_color']); ?>; }
@media screen and (max-width:750px) {
  #site_loader_logo_inner p { font-size:<?php echo esc_html($options['load_type4_catch_font_size_mobile']); ?>px; }
}
<?php
     };

     //フッターバー --------------------------------------------
     if(is_mobile()) {
       if($options['footer_bar_display'] == 'type1' || $options['footer_bar_display'] == 'type2') {
?>
.dp-footer-bar { background: <?php echo 'rgba('.implode(',', hex2rgb($options['footer_bar_bg'])).', '.esc_html($options['footer_bar_tp']).');'; ?> border-top: solid 1px <?php echo esc_html($options['footer_bar_border']); ?>; color: <?php echo esc_html($options['footer_bar_color']); ?>; display: flex; flex-wrap: wrap; }
.dp-footer-bar a { color: <?php echo esc_html($options['footer_bar_color']); ?>; }
.dp-footer-bar-item + .dp-footer-bar-item { border-left: solid 1px <?php echo esc_html($options['footer_bar_border']); ?>; }
<?php
       };
     };
?>

<?php
     // カスタムCSS --------------------------------------------
     if($options['css_code']) {
       echo wp_kses_post($options['css_code']);
     };
     if(is_single() || is_page()) {
       global $post;
       $custom_css = get_post_meta($post->ID, 'custom_css', true);
       if($custom_css) {
         echo wp_kses_post($custom_css);
       };
     }
?>

</style>

<?php
     // JavaScriptの設定はここから　■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

     // トップページ
     if(is_front_page()) {
       // 画像スライダー --------------------------------------------------
       if($options['index_header_content_type'] == 'type1'){
         wp_enqueue_style('slick-style', apply_filters('page_builder_slider_slick_style_url', get_template_directory_uri().'/js/slick.css'), '', '1.0.0');
         wp_enqueue_script('slick-script', apply_filters('page_builder_slider_slick_script_url', get_template_directory_uri().'/js/slick.min.js'), '', '1.0.0', true);
?>
<script type="text/javascript">
jQuery(document).ready(function($){

  $('#index_slider').slick({
    infinite: true,
    dots: false,
    arrows: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    adaptiveHeight: false,
    pauseOnFocus: true,
    pauseOnHover: false,
    autoplay: true,
    fade: true,
    slide: '.item',
    easing: 'easeOutExpo',
    speed: 1500,
    autoplaySpeed: <?php echo esc_html($options['index_slider_time']); ?>
  });
  $('#index_slider').on("beforeChange", function(event, slick, currentSlide, nextSlide) {
    $('#index_slider .item').removeClass('first_item');
    $('#index_slider .logo, #index_slider .catch, #index_slider .desc, #index_slider .button, #index_slider .search_area').removeClass('animate');
  });

});
</script>
<?php
     };
     // Video ------------------------------------------------------------
     if($options['index_header_content_type'] == 'type2') {
       if (auto_play_movie()) {
?>
<script type="text/javascript">
jQuery(document).ready(function($){

var mql = window.matchMedia('screen and (min-width: 1051px)');
function checkBreakPoint(mql) {

 if(mql.matches){ //PC

   var winH = <?php if($options['index_header_content_height'] == 'type1') { echo "'1000'"; } else { echo "window.innerHeight"; }; ?>;
   $('#index_video').outerHeight(winH);

   $(window).on('load',function(){
     setBgImg($('#index_video_mp4'));
   });

   $(window).on('resize',function(){
     winH = <?php if($options['index_header_content_height'] == 'type1') { echo "'1000'"; } else { echo "window.innerHeight"; }; ?>;
     $('#index_video').outerHeight(winH);
     setBgImg($('#index_video_mp4'));
   });

   function setBgImg(object){
     var imgW = object.width();
     var imgH = object.height();
     var winW = $(window).width();
     var winH = <?php if($options['index_header_content_height'] == 'type1') { echo "'1000'"; } else { echo "window.innerHeight"; }; ?>;
     var scaleW = winW / imgW;
     var scaleH = winH / imgH;
     var fixScale = Math.max(scaleW, scaleH);
     var setW = imgW * fixScale;
     var setH = imgH * fixScale;
     var moveX = Math.floor((winW - setW) / 2);
     var moveY = Math.floor((winH - setH) / 2);
     object.css({'width': setW, 'height': setH, 'left' : moveX, 'top' : moveY });
   }

 } else { //smart phone

   var winH = window.innerHeight - 60;
   $('#index_video').outerHeight(winH);

   $(window).on('load',function(){
     setBgImg($('#index_video_mp4'));
   });

   var windowWidth = $(window).width();
   $(window).on('resize',function(){
     if ($(window).width() != windowWidth) {
       winH = window.innerHeight - 60;
       $('#index_video').outerHeight(winH);
       setBgImg($('#index_video_mp4'));
       windowWidth = $(window).width();
     }
   });

   function setBgImg(object){
     var imgW = object.width();
     var imgH = object.height();
     var winW = $(window).width();
     var winH = window.innerHeight - 60;
     var scaleW = winW / imgW;
     var scaleH = winH / imgH;
     var fixScale = Math.max(scaleW, scaleH);
     var setW = imgW * fixScale;
     var setH = imgH * fixScale;
     var moveX = Math.floor((winW - setW) / 2);
     var moveY = Math.floor((winH - setH) / 2);
     object.css({'width': setW, 'height': setH, 'left' : moveX, 'top' : moveY });
   }

 };
};
mql.addListener(checkBreakPoint);
checkBreakPoint(mql);

});
</script>
<?php
       };
     };
     // Youtube ------------------------------------------------------------
     if($options['index_header_content_type'] == 'type3') {
       if(auto_play_movie()) {
?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/js/jquery.mb.YTPlayer.min.css?ver=<?php echo version_num(); ?>">
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.mb.YTPlayer.min.js?ver=<?php echo version_num(); ?>"></script>
<script type="text/javascript">
jQuery(document).ready(function($) {
  $("#youtube_video_player").YTPlayer();
});
</script>
<?php
       };
     };
     // ニュースティッカー --------------------------------------------------
     if($options['show_index_news']){
       wp_enqueue_style('slick-style', apply_filters('page_builder_slider_slick_style_url', get_template_directory_uri().'/js/slick.css'), '', '1.0.0');
       wp_enqueue_script('slick-script', apply_filters('page_builder_slider_slick_script_url', get_template_directory_uri().'/js/slick.min.js'), '', '1.0.0', true);
?>
<script type="text/javascript">
jQuery(document).ready(function($) {

  $('#index_news').slick({
    infinite: true,
    dots: false,
    arrows: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    adaptiveHeight: false,
    pauseOnFocus: false,
    pauseOnHover: false,
    autoplay: true,
    fade: true,
//    vertical: true,
    easing: 'easeOutExpo',
    speed: 1500,
    autoplaySpeed: <?php echo esc_html($options['index_news_time']); ?>
  });

});
</script>
<?php
       };
     // コンテンツビルダー -------------------------------------
     if (!empty($options['contents_builder'])) {
?>
<script type="text/javascript">
jQuery(document).ready(function($){
  $('.cb_contents:last').addClass('last');
<?php
     // スライダー
     foreach($options['contents_builder'] as $content) :
       if($content['cb_content_select'] == 'carousel') {
         wp_enqueue_style('slick-style', apply_filters('page_builder_slider_slick_style_url', get_template_directory_uri().'/js/slick.css'), '', '1.0.0');
         wp_enqueue_script('slick-script', apply_filters('page_builder_slider_slick_script_url', get_template_directory_uri().'/js/slick.min.js'), '', '1.0.0', true);
?>
  $('.index_carousel').slick({
    infinite: true,
    dots: false,
    arrows: true,
    slidesToShow: 3,
    adaptiveHeight: false,
    pauseOnFocus: false,
    pauseOnHover: false,
    autoplay: true,
    easing: 'easeOutExpo',
    speed: 700,
    autoplaySpeed: 5000,
    responsive: [
      {
        breakpoint: 1050,
        settings: { slidesToShow: 2 }
      },
      {
        breakpoint: 650,
        settings: { slidesToShow: 1, centerMode: true, variableWidth: true, }
      }
    ]
  });
<?php
         break;
       }
     endforeach;
?>
});
</script>
<?php
         }; // END content builder
       }; // END front page

     }; // END function tcd_head()

     add_action("wp_head", "tcd_head");
?>
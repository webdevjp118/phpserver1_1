<?php

function work_meta_box() {
  $options = get_design_plus_option();
  $box_label = $options['work_label'] ? esc_html( $options['work_label'] ) : __( 'Service', 'tcd-w' );
  add_meta_box(
    'work_meta_box',//ID of meta box
    sprintf(__('%s information', 'tcd-w'), $box_label),//label
    'show_work_meta_box',//callback function
    'work',// post type
    'normal',// context
    'high'// priority
  );
}
add_action('add_meta_boxes', 'work_meta_box');

function show_work_meta_box() {
  global $post;

  $work_contents_builder = get_post_meta( $post->ID, 'work_contents_builder', true );

  echo '<input type="hidden" name="work_custom_fields_meta_box_nonce" value="' . wp_create_nonce( basename( __FILE__ ) ) . '">';
?>
<div class="tcd_custom_field_wrap">

 <div class="theme_option_message" style="margin-top:0;">
  <?php _e( '<p>STEP1: Click Add content button.<br />STEP2: Select content from dropdown menu.<br />STEP3: Input data and save.</p><br /><p>You can change order by dragging MOVE button and you can delete content by clicking DELETE button.</p>', 'tcd-w' ); ?>
 </div>

 <div id="contents_builder_wrap">
  <div id="contents_builder">
   <p class="cb_message"><?php _e( 'Click Add content button to start content builder', 'tcd-w' ); ?></p>
<?php
if ( $work_contents_builder && is_array( $work_contents_builder ) ) :
	foreach( $work_contents_builder as $key => $content ) :
		$cb_index = 'cb_' . $key . '_' . mt_rand( 0, 999999 );
?>
   <div class="cb_row">
    <ul class="cb_button cf">
     <li><span class="cb_move"><?php _e( 'Move', 'tcd-w' ); ?></span></li>
     <li><span class="cb_delete"><?php _e( 'Delete', 'tcd-w' ); ?></span></li>
    </ul>
    <div class="cb_column_area cf">
     <div class="cb_column">
      <input type="hidden" class="cb_index" value="<?php echo $cb_index; ?>">
<?php
		the_work_cb_content_select( $cb_index, $content['content_select'] );
		if ( ! empty( $content['content_select'] ) ) :
			the_work_cb_content_setting( $cb_index, $content['content_select'], $content );
		endif;
?>
     </div><!-- END .cb_column -->
    </div><!-- END .cb_column_area -->
   </div><!-- END .cb_row -->
<?php
	endforeach;
endif;
?>
  </div><!-- END #contents_builder -->
  <ul class="button_list cf" id="cb_add_row_buttton_area">
   <li><input type="button" value="<?php _e( 'Add content', 'tcd-w' ); ?>" class="button-ml add_row"></li>
  </ul>
 </div><!-- END #contents_builder_wrap -->

 <?php // コンテンツビルダー追加用 非表示 ?>
 <div id="contents_builder-clone" class="hidden">
  <div class="cb_row">
   <ul class="cb_button cf">
    <li><span class="cb_move"><?php _e( 'Move', 'tcd-w' ); ?></span></li>
    <li><span class="cb_delete"><?php _e( 'Delete', 'tcd-w' ); ?></span></li>
   </ul>
   <div class="cb_column_area cf">
    <div class="cb_column">
     <input type="hidden" class="cb_index" value="cb_cloneindex">
       <?php the_work_cb_content_select( 'cb_cloneindex' ); ?>
    </div><!-- END .cb_column -->
   </div><!-- END .cb_column_area -->
  </div><!-- END .cb_row -->
<?php
foreach ( work_cb_get_contents() as $key => $value ) :
	the_work_cb_content_setting( 'cb_cloneindex', $key );
endforeach;
?>
 </div><!-- END #contents_builder-clone.hidden -->

</div><!-- END .tcd_custom_field_wrap -->
<?php
}

function save_work_meta_box( $post_id ) {
  // verify nonce
  if ( ! isset( $_POST['work_custom_fields_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['work_custom_fields_meta_box_nonce'], basename( __FILE__ ) ) ) {
    return $post_id;
  }

  // check autosave
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
    return $post_id;
  }

  // check permissions
  if ( 'page' == $_POST['post_type'] ) {
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
      return $post_id;
    }
  } elseif ( ! current_user_can( 'edit_post', $post_id ) ) {
    return $post_id;
  }

	// コンテンツビルダー 整形保存
	if ( ! empty( $_POST['work_contents_builder'] ) && is_array( $_POST['work_contents_builder'] ) ) {
		$cb_contents = work_cb_get_contents();
		$cb_data = array();

		foreach ( $_POST['work_contents_builder'] as $key => $value ) {
			// クローン用はスルー
			if ( 'cb_cloneindex' === $key ) continue;

			// コンテンツデフォルト値に入力値をマージ
			if ( ! empty( $value['content_select'] ) && isset( $cb_contents[$value['content_select']]['default'] ) ) {
				$value = array_merge( (array) $cb_contents[$value['content_select']]['default'], $value );
			}

			// 段落
			if ( 'text_and_images' === $value['content_select'] ) {
				$value['display'] = ! empty( $value['display'] ) ? 1 : 0;
				$value['catch'] = sanitize_textarea_field( $value['catch'] );
				$value['catch_color'] = sanitize_hex_color( $value['catch_color'] );
				$value['catch_font_size'] = absint( $value['catch_font_size'] );
				$value['catch_font_size_mobile'] = absint( $value['catch_font_size_mobile'] );
				$value['desc'] = $value['desc'];

				$images = array();
				if ( $value['images'] && is_array( $value['images'] ) ) {
					foreach( array_values( $value['images'] ) as $repeater_value ) {
						$repeater_value = array_merge( $cb_contents[$value['content_select']]['repeater_images_row_default'], $repeater_value );
						$images[] = array(
							'image' => absint( $repeater_value['image'] ),
							'size' => array_key_exists( $repeater_value['size'], $cb_contents[$value['content_select']]['repeater_images_size_options'] ) ? $repeater_value['size'] : $cb_contents[$value['content_select']]['repeater_images_row_default']['size']
						);
					}
				}
				$value['images'] = $images;

			// 情報一覧
			} elseif ( 'data_list' === $value['content_select'] ) {
				$value['display'] = ! empty( $value['display'] ) ? 1 : 0;
				$value['catch'] = sanitize_textarea_field( $value['catch'] );
				$value['catch_color'] = sanitize_hex_color( $value['catch_color'] );
				$value['catch_font_size'] = absint( $value['catch_font_size'] );
				$value['catch_font_size_mobile'] = absint( $value['catch_font_size_mobile'] );

				$value['show_button'] = ! empty( $value['show_button'] ) ? 1 : 0;
				$value['button_label'] = sanitize_text_field( $value['button_label'] );
				$value['button_url'] = sanitize_text_field( $value['button_url'] );
				$value['button_target_blank'] = ! empty( $value['button_target_blank'] ) ? 1 : 0;
				$value['button_font_color'] = sanitize_hex_color( $value['button_font_color'] );
				$value['button_bg_color'] = sanitize_hex_color( $value['button_bg_color'] );
				$value['button_font_color_hover'] = sanitize_hex_color( $value['button_font_color_hover'] );
				$value['button_bg_color_hover'] = sanitize_hex_color( $value['button_bg_color_hover'] );

				$datas = array();
				if ( $value['datas'] && is_array( $value['datas'] ) ) {
					foreach( array_values( $value['datas'] ) as $repeater_value ) {
						$datas[] = array_merge( $cb_contents[$value['content_select']]['repeater_datas_row_default'], $repeater_value );
					}
				}
				$value['datas'] = $datas;
			}

			$cb_data[] = $value;
		}

		if ( $cb_data ) {
			update_post_meta( $post_id, 'work_contents_builder', $cb_data );
		} else {
			delete_post_meta( $post_id, 'work_contents_builder' );
		}
	}
}
add_action('save_post', 'save_work_meta_box');

/**
 * コンテンツビルダー コンテンツ一覧取得
 */
function work_cb_get_contents() {
	return array(
		'text_and_images' => array(
			'name' => 'text_and_images',
			'label' => __( 'Text and images', 'tcd-w' ),
			'default' => array(
				'display' => 0,
				'catch' => '',
				'catch_color' => '#000000',
				'catch_font_size' => 32,
				'catch_font_size_mobile' => 21,
				'desc' => '',
				'images' => array()
			),
			'repeater_images_row_default' => array(
				'image' => 0,
				'size' => 'type1'
			),
			'repeater_images_size_options' => array(
				'type1' => __( 'Full width image', 'tcd-w' ) . ' <small>' . sprintf( __( 'Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w' ), '800', '485' ) . '</small>',
				'type2' => __( 'Half width image', 'tcd-w' ) . ' <small>' . sprintf( __( 'Recommend image size. Width:%1$spx, Height:%2$spx.', 'tcd-w' ), '395', '240' ) . '</small>'
			)
		),
		'data_list' => array(
			'name' => 'data_list',
			'label' => __( 'Data list', 'tcd-w' ),
			'default' => array(
				'display' => 0,
				'catch' => '',
				'catch_color' => '#000000',
				'catch_font_size' => 32,
				'catch_font_size_mobile' => 21,
				'datas' => array(),
				'show_button' => 0,
				'button_label' => '',
				'button_url' => '',
				'button_target_blank' => 0,
				'button_font_color' => '#ffffff',
				'button_bg_color' => '#000000',
				'button_font_color_hover' => '#ffffff',
				'button_bg_color_hover' => '#333333'
			),
			'repeater_datas_row_default' => array(
				'title' => '',
				'desc' => ''
			)
		)
	);
}

/**
 * コンテンツビルダー用 コンテンツ選択プルダウン
 */
function the_work_cb_content_select( $cb_index = 'cb_cloneindex', $selected = null ) {
	$cb_contents = work_cb_get_contents();

	if ( $selected && isset( $cb_contents[$selected] ) ) {
		$add_class = ' hidden';
	} else {
		$add_class = '';
	}

	$out = '<select name="work_contents_builder[' . esc_attr( $cb_index ) . '][content_select]" class="cb_content_select' . $add_class . '">';
	$out .= '<option value="">' . __( 'Choose the content', 'tcd-w' ) . '</option>';

	foreach ( $cb_contents as $key => $value ) {
		$out .= '<option value="' . esc_attr( $key ) . '"' . selected( $key, $selected, false ) . '>' . esc_html( $value['label'] ) . '</option>';
	}

	$out .= '</select>';

	echo $out;
}

/**
 * コンテンツビルダー用 コンテンツ設定
 */
function the_work_cb_content_setting( $cb_index = 'cb_cloneindex', $cb_content_select = null, $value = array() ) {

	$cb_contents = work_cb_get_contents();

	// 不明なコンテンツの場合は終了
	if ( ! $cb_content_select || ! isset( $cb_contents[$cb_content_select] ) ) return false;

	// コンテンツデフォルト値に入力値をマージ
	if ( isset( $cb_contents[$cb_content_select]['default'] ) ) {
		$value = array_merge( (array) $cb_contents[$cb_content_select]['default'], $value );
	}
?>
	<div class="cb_content_wrap cf <?php echo esc_attr( $cb_content_select ); ?>">
<?php
	// 段落
	if ( 'text_and_images' === $cb_content_select ) :
?>
		<h3 class="cb_content_headline"><?php echo esc_html( $cb_contents[$cb_content_select]['label'] ); ?><span></span></h3>
		<div class="cb_content">
			<p><label><input name="work_contents_builder[<?php echo $cb_index; ?>][display]" type="checkbox" value="1" <?php checked( $value['display'], 1 ); ?>><?php _e( 'Display this content', 'tcd-w' ); ?></label></p>

			<h4 class="theme_option_headline2"><?php _e( 'Catchphrase', 'tcd-w' ); ?></h4>
			<textarea class="large-text change_content_headline" name="work_contents_builder[<?php echo $cb_index; ?>][catch]" rows="2"><?php echo esc_textarea( $value['catch'] ); ?></textarea>
			<ul class="option_list">
				<li class="cf"><span class="label"><?php _e( 'Font color', 'tcd-w' ); ?></span><input type="text" name="work_contents_builder[<?php echo $cb_index; ?>][catch_color]" value="<?php echo esc_attr( $value['catch_color'] ); ?>" class="c-color-picker" data-default-color="<?php echo esc_attr( $cb_contents[$cb_content_select]['default']['catch_color'] ); ?>"></li>
				<li class="cf"><span class="label"><?php _e( 'Font size', 'tcd-w' ); ?></span><input type="number" class="small-text" name="work_contents_builder[<?php echo $cb_index; ?>][catch_font_size]" value="<?php echo esc_attr( $value['catch_font_size'] ); ?>" min="1"><span>px</span></li>
				<li class="cf"><span class="label"><?php _e( 'Font size for mobile', 'tcd-w' ); ?></span><input type="number" class="small-text" name="work_contents_builder[<?php echo $cb_index; ?>][catch_font_size_mobile]" value="<?php echo esc_attr( $value['catch_font_size_mobile'] ); ?>" min="1"><span>px</span></li>
			</ul>

			<h4 class="theme_option_headline2"><?php _e( 'Description', 'tcd-w' ); ?></h4>
<?php
		wp_editor(
			$value['desc'],
			'wysiwyg_editor-' . $cb_index,
			array(
				'textarea_name' => 'work_contents_builder[' . $cb_index . '][desc]',
				'textarea_rows' => 10
			)
		);
?>

			<h4 class="theme_option_headline2"><?php _e( 'Images', 'tcd-w' ); ?></h4>
			<div class="theme_option_message2">
				<p><?php _e('You can change order by dragging each item.', 'tcd-w'); ?></p>
			</div>
			<div class="repeater-wrapper">
				<div class="repeater sortable" data-delete-confirm="<?php _e( 'Delete?', 'tcd-w' ); ?>">
<?php
		if ( $value['images'] && is_array( $value['images'] ) ) :
			foreach ( $value['images'] as $repeater_key => $repeater_value ) :
				$repeater_value = array_merge( $cb_contents[$cb_content_select]['repeater_images_row_default'], $repeater_value );
?>
					<div class="sub_box repeater-item repeater-item-<?php echo esc_attr( $repeater_key ); ?>">
						<h4 class="theme_option_subbox_headline"><?php _e( 'Image', 'tcd-w' ); echo esc_html( $repeater_key + 1 ); ?></h4>
						<div class="sub_box_content">
							<h4 class="theme_option_headline2"><?php _e( 'Image', 'tcd-w' ); ?></h4>
							<div class="cf cf_media_field hide-if-no-js">
								<input type="hidden" class="cf_media_id" name="work_contents_builder[<?php echo $cb_index; ?>][images][<?php echo esc_attr( $repeater_key ); ?>][image]" id="work_contents_builder-<?php echo $cb_index; ?>-images-<?php echo esc_attr( $repeater_key ); ?>-image" value="<?php echo esc_attr( $repeater_value['image'] ); ?>">
								<div class="preview_field"><?php if ( $repeater_value['image'] ) echo wp_get_attachment_image( $repeater_value['image'], 'medium' ); ?></div>
								<div class="buttton_area">
									<input type="button" class="cfmf-select-img button" value="<?php _e( 'Select Image', 'tcd-w' ); ?>">
									<input type="button" class="cfmf-delete-img button<?php if ( ! $repeater_value['image'] ) echo ' hidden'; ?>" value="<?php _e( 'Remove Image', 'tcd-w'); ?>">
								</div>
							</div>
							<h4 class="theme_option_headline2"><?php _e( 'Image size', 'tcd-w' ); ?></h4>
							<ul>
<?php
		foreach ( $cb_contents[$cb_content_select]['repeater_images_size_options'] as $option_key => $option_label ) :
?>
								<li><label><input type="radio" name="work_contents_builder[<?php echo $cb_index; ?>][images][<?php echo esc_attr( $repeater_key ); ?>][size]" value="<?php echo esc_attr( $option_key ); ?>" <?php checked( $repeater_value['size'], $option_key ); ?>><?php echo $option_label; ?></small></label></li>
<?php
		endforeach;
?>
							</ul>
							<p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
						</div><!-- END .sub_box_content -->
					</div><!-- END .sub_box -->
<?php
			endforeach;
		endif;

		$repeater_key = 'addindex';
		$repeater_value = $cb_contents[$cb_content_select]['repeater_images_row_default'];
		ob_start();
?>
					<div class="sub_box repeater-item repeater-item-<?php echo esc_attr( $repeater_key ); ?>">
						<h4 class="theme_option_subbox_headline"><?php _e( 'New item', 'tcd-w' ); ?></h4>
						<div class="sub_box_content">
							<h4 class="theme_option_headline2"><?php _e( 'Image', 'tcd-w' ); ?></h4>
							<div class="cf cf_media_field hide-if-no-js">
								<input type="hidden" class="cf_media_id" name="work_contents_builder[<?php echo $cb_index; ?>][images][<?php echo esc_attr( $repeater_key ); ?>][image]" id="work_contents_builder-<?php echo $cb_index; ?>-images-<?php echo esc_attr( $repeater_key ); ?>-image" value="<?php echo esc_attr( $repeater_value['image'] ); ?>">
								<div class="preview_field"><?php if ( $repeater_value['image'] ) wp_get_attachment_image( $repeater_value['image'], 'medium' ); ?></div>
								<div class="buttton_area">
									<input type="button" class="cfmf-select-img button" value="<?php _e( 'Select Image', 'tcd-w' ); ?>">
									<input type="button" class="cfmf-delete-img button<?php if ( ! $repeater_value['image'] ) echo ' hidden'; ?>" value="<?php _e( 'Remove Image', 'tcd-w'); ?>">
								</div>
							</div>
							<h4 class="theme_option_headline2"><?php _e( 'Image size', 'tcd-w' ); ?></h4>
							<ul>
<?php
		foreach ( $cb_contents[$cb_content_select]['repeater_images_size_options'] as $option_key => $option_label ) :
?>
								<li><label><input type="radio" name="work_contents_builder[<?php echo $cb_index; ?>][images][<?php echo esc_attr( $repeater_key ); ?>][size]" value="<?php echo esc_attr( $option_key ); ?>" <?php checked( $repeater_value['size'], $option_key ); ?>><?php echo $option_label; ?></small></label></li>
<?php
		endforeach;
?>
							</ul>
							<p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
						</div><!-- END .sub_box_content -->
					</div><!-- END .sub_box -->
<?php
		$clone = ob_get_clean();
?>
				</div><!-- END .repeater -->
				<a href="#" class="button button-secondary button-add-row" data-clone="<?php echo esc_attr( $clone ); ?>"><?php _e( 'Add item', 'tcd-w' ); ?></a>
			</div><!-- END .repeater-wrapper -->

			<ul class="button_list cf">
				<li><a href="#" class="button-ml close-content"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
			</ul>
		</div>

<?php
	// 情報一覧
	elseif ( 'data_list' === $cb_content_select ) :
?>
		<h3 class="cb_content_headline"><?php echo esc_html( $cb_contents[$cb_content_select]['label'] ); ?><span></span></h3>
		<div class="cb_content">
			<p><label><input name="work_contents_builder[<?php echo $cb_index; ?>][display]" type="checkbox" value="1" <?php checked( $value['display'], 1 ); ?>><?php _e( 'Display this content', 'tcd-w' ); ?></label></p>

			<h4 class="theme_option_headline2"><?php _e( 'Catchphrase', 'tcd-w' ); ?></h4>
			<textarea class="large-text change_content_headline" name="work_contents_builder[<?php echo $cb_index; ?>][catch]" rows="2"><?php echo esc_textarea( $value['catch'] ); ?></textarea>
			<ul class="option_list">
				<li class="cf"><span class="label"><?php _e( 'Font color', 'tcd-w' ); ?></span><input type="text" name="work_contents_builder[<?php echo $cb_index; ?>][catch_color]" value="<?php echo esc_attr( $value['catch_color'] ); ?>" class="c-color-picker" data-default-color="<?php echo esc_attr( $cb_contents[$cb_content_select]['default']['catch_color'] ); ?>"></li>
				<li class="cf"><span class="label"><?php _e( 'Font size', 'tcd-w' ); ?></span><input type="number" class="small-text" name="work_contents_builder[<?php echo $cb_index; ?>][catch_font_size]" value="<?php echo esc_attr( $value['catch_font_size'] ); ?>" min="1"><span>px</span></li>
				<li class="cf"><span class="label"><?php _e( 'Font size for mobile', 'tcd-w' ); ?></span><input type="number" class="small-text" name="work_contents_builder[<?php echo $cb_index; ?>][catch_font_size_mobile]" value="<?php echo esc_attr( $value['catch_font_size_mobile'] ); ?>" min="1"><span>px</span></li>
			</ul>

			<h4 class="theme_option_headline2"><?php _e( 'Data list', 'tcd-w' ); ?></h4>
			<div class="theme_option_message2">
				<p><?php _e('You can change order by dragging each item.', 'tcd-w'); ?></p>
			</div>
			<div class="repeater-wrapper">
				<div class="repeater sortable" data-delete-confirm="<?php _e( 'Delete?', 'tcd-w' ); ?>">
<?php
		if ( $value['datas'] && is_array( $value['datas'] ) ) :
			foreach ( $value['datas'] as $repeater_key => $repeater_value ) :
				$repeater_value = array_merge( $cb_contents[$cb_content_select]['repeater_datas_row_default'], $repeater_value );
?>
					<div class="sub_box repeater-item repeater-item-<?php echo esc_attr( $repeater_key ); ?>">
						<h4 class="theme_option_subbox_headline"><?php _e( 'New item', 'tcd-w' ); ?></h4>
						<div class="sub_box_content">
							<h4 class="theme_option_headline2"><?php _e( 'Headline', 'tcd-w' ); ?></h4>
							<p><input class="repeater-label large-text" type="text" name="work_contents_builder[<?php echo $cb_index; ?>][datas][<?php echo esc_attr( $repeater_key ); ?>][title]" value="<?php echo esc_attr( isset( $repeater_value['title'] ) ? $repeater_value['title'] : '' ); ?>"></p>
							<h4 class="theme_option_headline2"><?php _e( 'Description', 'tcd-w' ); ?></h4>
							<textarea class="large-text" cols="50" rows="2" name="work_contents_builder[<?php echo $cb_index; ?>][datas][<?php echo esc_attr( $repeater_key ); ?>][desc]"><?php echo esc_textarea( isset( $repeater_value['desc'] ) ? $repeater_value['desc'] : '' ); ?></textarea>
							<p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
						</div><!-- END .sub_box_content -->
					</div><!-- END .sub_box -->
<?php
			endforeach;
		endif;

		$repeater_key = 'addindex';
		$repeater_value = $cb_contents[$cb_content_select]['repeater_datas_row_default'];
		ob_start();
?>
					<div class="sub_box repeater-item repeater-item-<?php echo esc_attr( $repeater_key ); ?>">
						<h4 class="theme_option_subbox_headline"><?php _e( 'New item', 'tcd-w' ); ?></h4>
						<div class="sub_box_content">
							<h4 class="theme_option_headline2"><?php _e( 'Headline', 'tcd-w' ); ?></h4>
							<p><input class="repeater-label large-text" type="text" name="work_contents_builder[<?php echo $cb_index; ?>][datas][<?php echo esc_attr( $repeater_key ); ?>][title]" value="<?php echo esc_attr( isset( $repeater_value['title'] ) ? $repeater_value['title'] : '' ); ?>"></p>
							<h4 class="theme_option_headline2"><?php _e( 'Description', 'tcd-w' ); ?></h4>
							<textarea class="large-text" cols="50" rows="2" name="work_contents_builder[<?php echo $cb_index; ?>][datas][<?php echo esc_attr( $repeater_key ); ?>][desc]"><?php echo esc_textarea( isset( $repeater_value['desc'] ) ? $repeater_value['desc'] : '' ); ?></textarea>
							<p class="delete-row right-align"><a href="#" class="button button-secondary button-delete-row"><?php _e( 'Delete item', 'tcd-w' ); ?></a></p>
						</div><!-- END .sub_box_content -->
					</div><!-- END .sub_box -->
<?php
		$clone = ob_get_clean();
?>
				</div><!-- END .repeater -->
				<a href="#" class="button button-secondary button-add-row" data-clone="<?php echo esc_attr( $clone ); ?>"><?php _e( 'Add item', 'tcd-w' ); ?></a>
			</div><!-- END .repeater-wrapper -->

			<h4 class="theme_option_headline2"><?php _e( 'Button setting', 'tcd-w' ); ?></h4>
			<p class="displayment_checkbox">
				<input name="work_contents_builder[<?php echo $cb_index; ?>][show_button]" type="hidden" value="">
				<label><input name="work_contents_builder[<?php echo $cb_index; ?>][show_button]" type="checkbox" value="1" <?php checked( $value['show_button'], 1 ); ?>><?php _e( 'Display button', 'tcd-w' ); ?></label>
			</p>
			<ul class="option_list<?php if ( ! $value['show_button'] ) echo ' hidden'; ?>" style="border-top:1px dotted #ddd; padding:8px 0 0 0;">
				<li class="cf"><span class="label"><?php _e( 'Label', 'tcd-w' ); ?></span><input class="full_width" type="text" name="work_contents_builder[<?php echo $cb_index; ?>][button_label]" value="<?php echo esc_attr( $value['button_label'] ); ?>"></li>
				<li class="cf"><span class="label"><?php _e( 'URL', 'tcd-w' ); ?></span><input class="full_width" type="text" name="work_contents_builder[<?php echo $cb_index; ?>][button_url]" value="<?php echo esc_attr( $value['button_url'] ); ?>"></li>
				<li class="cf"><label><input name="work_contents_builder[<?php echo $cb_index; ?>][button_target_blank]" type="checkbox" value="1" <?php checked( $value['button_target_blank'], 1 ); ?>> <?php _e( 'Open link in new window', 'tcd-w' ); ?></label></li>
				<li class="cf"><span class="label"><?php _e( 'Font color', 'tcd-w' ); ?></span><input type="text" name="work_contents_builder[<?php echo $cb_index; ?>][button_font_color]" value="<?php echo esc_attr( $value['button_font_color'] ); ?>" data-default-color="<?php echo esc_attr( $cb_contents[$cb_content_select]['default']['button_font_color'] ); ?>" class="c-color-picker"></li>
				<li class="cf"><span class="label"><?php _e( 'Background color', 'tcd-w' ); ?></span><input type="text" name="work_contents_builder[<?php echo $cb_index; ?>][button_bg_color]" value="<?php echo esc_attr( $value['button_bg_color'] ); ?>"" data-default-color="<?php echo esc_attr( $cb_contents[$cb_content_select]['default']['button_bg_color'] ); ?>" class="c-color-picker"></li>
				<li class="cf"><span class="label"><?php _e('Font color on mouseover', 'tcd-w'); ?></span><input type="text" name="work_contents_builder[<?php echo $cb_index; ?>][button_font_color_hover]" value="<?php echo esc_attr( $value['button_font_color_hover'] ); ?>" data-default-color="<?php echo esc_attr( $cb_contents[$cb_content_select]['default']['button_font_color_hover'] ); ?>" class="c-color-picker"></li>
				<li class="cf"><span class="label"><?php _e('Background color on mouseover', 'tcd-w'); ?></span><input type="text" name="work_contents_builder[<?php echo $cb_index; ?>][button_bg_color_hover]" value="<?php echo esc_attr( $value['button_bg_color_hover'] ); ?>" data-default-color="<?php echo esc_attr( $cb_contents[$cb_content_select]['default']['button_bg_color_hover'] ); ?>" class="c-color-picker"></li>
			</ul>

			<ul class="button_list cf">
				<li><a href="#" class="button-ml close-content"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
			</ul>
		</div>
<?php
	else :
?>
		<h3 class="cb_content_headline"><?php echo esc_html( $cb_content_select ); ?></h3>
		<div class="cb_content">
			<ul class="button_list cf">
				<li><a href="#" class="button-ml close-content"><?php echo __( 'Close', 'tcd-w' ); ?></a></li>
			</ul>
		</div>
<?php
	endif;
?>
	</div><!-- END .cb_content_wrap -->
<?php
}

/**
 * クローン用のリッチエディター化処理をしないようにする
 * クローン後のリッチエディター化はjsで行う
 */
function work_cb_tiny_mce_before_init( $mceInit, $editor_id ) {
	if ( strpos( $editor_id, 'cb_cloneindex' ) !== false ) {
		$mceInit['wp_skip_init'] = true;
	}
	return $mceInit;
}
add_filter( 'tiny_mce_before_init', 'work_cb_tiny_mce_before_init', 10, 2 );

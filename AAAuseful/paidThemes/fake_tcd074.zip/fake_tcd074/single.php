<?php
     get_header();
     $options = get_design_plus_option();
     $title = $options['blog_label'];

     $image_id = $options['blog_bg_image'];
     $image_id_mobile = $options['blog_bg_image_mobile'];
     $background_color = $options['blog_bg_color'];

     $use_overlay = $options['blog_use_overlay'];
     if($use_overlay) {
       $overlay_color = hex2rgb($options['blog_overlay_color']);
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = $options['blog_overlay_opacity'];
     }
     $category = get_the_category();
     $count=1;
     foreach ($category as $cat) {
       $cat_id = $cat->term_id;
       $count++;
     }
     $term_meta = get_option( 'taxonomy_' . $cat_id, array() );
     if (!empty($term_meta['image'])){
       $image_id = $term_meta['image'];
     }
     if (!empty($term_meta['image_mobile'])){
       $image_id_mobile = $term_meta['image_mobile'];
     }
     if (!empty($term_meta['blog_use_overlay'])){
       if (!empty($term_meta['blog_overlay_color'])){
         $overlay_color = hex2rgb($term_meta['blog_overlay_color']);
         $overlay_color = implode(",",$overlay_color);
         if (!empty($term_meta['blog_overlay_opacity'])){
           $overlay_opacity = $term_meta['blog_overlay_opacity'];
         } else {
           $overlay_opacity = '0.3';
         }
       }
     }
?>
<div id="page_header" class="small" style="background:<?php echo $background_color; ?>;">
 <?php if($image_id && $use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
 <?php if($image_id || $image_id_mobile ) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($image_id)); ?>" data-parallax-mobile-image="<?php echo esc_attr(wp_get_attachment_url($image_id_mobile)); ?>" data-parallax-speed="0"></div><?php }; ?>
</div>

<?php get_template_part('template-parts/breadcrumb'); ?>

<div id="main_contents" class="clearfix">

 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

 <article id="article">

  <div id="post_title_area">
   <?php if ( $options['show_date'] ){ ?><p class="date"><time class="entry-date updated" datetime="<?php the_modified_time('c'); ?>"><?php the_time('Y.m.j'); ?></time></p><?php }; ?>
   <h1 class="title rich_font entry-title"><?php the_title(); ?></h1>
  </div>

  <?php if($page == '1') { // ***** only show on first page ***** ?>

  <?php
       // featured image ------------------------------------------------------------------------------------------------------------------------
       if($options['show_thumbnail'] && has_post_thumbnail()) {
  ?>
  <div id="post_image">
   <?php if ( $options['show_category'] ){ ?><p id="single_category"><?php the_category(' '); ?></p><?php }; ?>
   <?php the_post_thumbnail('size3'); ?>
  </div>
  <?php }; ?>

  <?php
       // sns button top ------------------------------------------------------------------------------------------------------------------------
       if($options['show_sns_top']) {
  ?>
  <div class="single_share clearfix" id="single_share_top">
   <?php get_template_part('template-parts/sns-btn-top'); ?>
  </div>
  <?php }; ?>

  <?php
       // banner top ------------------------------------------------------------------------------------------------------------------------
       if(!is_mobile()) {
         if( $options['single_top_ad_code1'] || $options['single_top_ad_image1'] || $options['single_top_ad_code2'] || $options['single_top_ad_image2'] ) {
  ?>
  <div id="single_banner_top" class="single_banner_area clearfix<?php if( !$options['single_top_ad_code2'] && !$options['single_top_ad_image2'] ) { echo ' one_banner'; }; ?>">
   <?php if ($options['single_top_ad_code1']) { ?>
   <div class="single_banner single_banner_left">
    <?php echo $options['single_top_ad_code1']; ?>
   </div>
   <?php } else { ?>
   <?php $single_image1 = wp_get_attachment_image_src( $options['single_top_ad_image1'], 'full' ); ?>
   <div class="single_banner single_banner_left">
    <a href="<?php echo esc_url( $options['single_top_ad_url1'] ); ?>" target="_blank"><img src="<?php echo esc_attr($single_image1[0]); ?>" alt="" title="" /></a>
   </div>
   <?php }; ?>
   <?php if ($options['single_top_ad_code2']) { ?>
   <div class="single_banner single_banner_right">
    <?php echo $options['single_top_ad_code2']; ?>
   </div>
   <?php } else { ?>
   <?php $single_image2 = wp_get_attachment_image_src( $options['single_top_ad_image2'], 'full' ); ?>
   <div class="single_banner single_banner_right">
    <a href="<?php echo esc_url( $options['single_top_ad_url2'] ); ?>" target="_blank"><img src="<?php echo esc_attr($single_image2[0]); ?>" alt="" title="" /></a>
   </div>
   <?php }; ?>
  </div><!-- END #single_banner_area -->
  <?php
         };
       };
  ?>

  <?php }; // ***** END only show on first page ***** ?>

  <?php // post content ------------------------------------------------------------------------------------------------------------------------ ?>
  <div class="post_content clearfix">
   <?php
        the_content();
        if ( ! post_password_required() ) {
          $pagenation_type = get_post_meta($post->ID, 'pagenation_type', true);
          if($pagenation_type == 'type3') {
            $pagenation_type = $options['pagenation_type'];
          };
          if ( $pagenation_type == 'type2' ) {
            if ( $page < $numpages && preg_match( '/href="(.*?)"/', _wp_link_page( $page + 1 ), $matches ) ) :
   ?>
   <div id="p_readmore">
    <a class="button" href="<?php echo esc_url( $matches[1] ); ?>#article"><?php _e( 'Read more', 'tcd-w' ); ?></a>
    <p class="num"><?php echo $page . ' / ' . $numpages; ?></p>
   </div>
   <?php
            endif;
          } else {
            custom_wp_link_pages();
          }
        }
   ?>
  </div>

  <?php
       // Author profile ------------------------------------------------------------------------------------------------------------------------------
       if($options['show_author_profile']) {
          $author_id = get_the_author_meta('ID');
          $user_data = get_userdata($author_id);
          $show_author = $user_data->show_author;
          if($show_author) {
            $catch = $user_data->description;
            $facebook = $user_data->facebook_url;
            $twitter = $user_data->twitter_url;
            $insta = $user_data->instagram_url;
            $pinterest = $user_data->pinterest_url;
            $youtube = $user_data->youtube_url;
            $contact = $user_data->contact_url;
            $author_url = get_author_posts_url($author_id);
  ?>
  <div class="author_profile clearfix">
   <a class="avatar animate_image square" href="<?php echo esc_url($author_url); ?>"><?php echo wp_kses_post(get_avatar($author_id, 300)); ?></a>
   <div class="info clearfix">
    <div class="title_area clearfix">
     <h4 class="name"><a href="<?php echo esc_url($author_url); ?>"><?php echo esc_html($user_data->display_name); ?></a></h4>
     <a class="archive_link" href="<?php echo esc_url($author_url); ?>"><span><?php _e("Post list","tcd-w"); ?></span></a>
    </div>
    <?php if($catch) { ?>
    <div class="desc">
     <?php echo wpautop($catch); ?>
    </div>
    <?php }; ?>
    <?php if($facebook || $twitter || $insta || $pinterest || $youtube || $contact ) { ?>
    <ul class="author_link clearfix">
     <?php if($facebook) { ?><li class="facebook"><a href="<?php echo esc_url($facebook); ?>" rel="nofollow" target="_blank" title="Facebook"><span>Facebook</span></a></li><?php }; ?>
     <?php if($twitter) { ?><li class="twitter"><a href="<?php echo esc_url($twitter); ?>" rel="nofollow" target="_blank" title="Twitter"><span>Twitter</span></a></li><?php }; ?>
     <?php if($insta) { ?><li class="insta"><a href="<?php echo esc_url($insta); ?>" rel="nofollow" target="_blank" title="Instagram"><span>Instagram</span></a></li><?php }; ?>
     <?php if($pinterest) { ?><li class="pinterest"><a href="<?php echo esc_url($pinterest); ?>" rel="nofollow" target="_blank" title="Pinterest"><span>Pinterest</span></a></li><?php }; ?>
     <?php if($youtube) { ?><li class="youtube"><a href="<?php echo esc_url($youtube); ?>" rel="nofollow" target="_blank" title="Youtube"><span>Youtube</span></a></li><?php }; ?>
     <?php if($contact) { ?><li class="contact"><a href="<?php echo esc_url($contact); ?>" rel="nofollow" target="_blank" title="Contact"><span>Contact</span></a></li><?php }; ?>
    </ul>
    <?php }; ?>
   </div>
  </div><!-- END .author_profile -->
  <?php }; }; ?>

  <?php
       // sns button ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       if($options['show_sns_btm']) {
  ?>
  <div class="single_share clearfix" id="single_share_bottom">
   <?php get_template_part('template-parts/sns-btn-btm'); ?>
  </div>
  <?php }; ?>

  <?php
       // meta ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       if ($options['show_meta_box']) {
  ?>
  <ul id="post_meta_bottom" class="clearfix">
   <?php if ($options['show_meta_author']) : ?><li class="post_author"><?php _e("Author","tcd-w"); ?>: <?php if (function_exists('coauthors_posts_links')) { coauthors_posts_links(', ',', ','','',true); } else { the_author_posts_link(); }; ?></li><?php endif; ?>
   <?php if ($options['show_meta_category']){ ?><li class="post_category"><?php the_category(', '); ?></li><?php }; ?>
   <?php if ($options['show_meta_tag']): ?><?php the_tags('<li class="post_tag">',', ','</li>'); ?><?php endif; ?>
   <?php if ($options['show_meta_comment']) : if (comments_open()){ ?><li class="post_comment"><?php _e("Comment","tcd-w"); ?>: <a href="#comment_headline"><?php comments_number( '0','1','%' ); ?></a></li><?php }; endif; ?>
  </ul>
  <?php }; ?>

  <?php
       // page nav ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       if ($options['show_next_post']) :
  ?>
  <div id="next_prev_post" class="clearfix">
   <?php next_prev_post_link(); ?>
  </div>
  <?php endif; ?>

 </article><!-- END #article -->

 <?php endwhile; endif; ?>

 <?php
      // banner bottom ------------------------------------------------------------------------------------------------------------------------
      if(!is_mobile()) {
        if( $options['single_bottom_ad_code1'] || $options['single_bottom_ad_image1'] || $options['single_bottom_ad_code2'] || $options['single_bottom_ad_image2'] ) {
 ?>
 <div id="single_banner_bottom" class="single_banner_area clearfix<?php if( !$options['single_bottom_ad_code2'] && !$options['single_bottom_ad_image2'] ) { echo ' one_banner'; }; ?>">
  <?php if ($options['single_bottom_ad_code1']) { ?>
  <div class="single_banner single_banner_left">
   <?php echo $options['single_bottom_ad_code1']; ?>
  </div>
  <?php } else { ?>
  <?php $single_image1 = wp_get_attachment_image_src( $options['single_bottom_ad_image1'], 'full' ); ?>
  <div class="single_banner single_banner_left">
   <a href="<?php echo esc_url( $options['single_bottom_ad_url1'] ); ?>" target="_blank"><img src="<?php echo esc_attr($single_image1[0]); ?>" alt="" title="" /></a>
  </div>
  <?php }; ?>
  <?php if ($options['single_bottom_ad_code2']) { ?>
  <div class="single_banner single_banner_right">
   <?php echo $options['single_bottom_ad_code2']; ?>
  </div>
  <?php } else { ?>
  <?php $single_image2 = wp_get_attachment_image_src( $options['single_bottom_ad_image2'], 'full' ); ?>
  <div class="single_banner single_banner_right">
   <a href="<?php echo esc_url( $options['single_bottom_ad_url2'] ); ?>" target="_blank"><img src="<?php echo esc_attr($single_image2[0]); ?>" alt="" title="" /></a>
  </div>
  <?php }; ?>
 </div><!-- END #single_banner_area -->
 <?php
        };
      };
 ?>

 <?php
      // mobile banner ------------------------------------------------------------------------------------------------------------------------
      if(is_mobile()) {
 ?>
 <?php if( $options['single_mobile_ad_code1'] || $options['single_mobile_ad_image1'] ) { ?>
 <div id="mobile_banner_top" class="single_banner_area one_banner">
  <?php if ($options['single_mobile_ad_code1']) { ?>
  <div class="single_banner">
   <?php echo $options['single_mobile_ad_code1']; ?>
  </div>
  <?php } else { ?>
  <?php $single_mobile_image = wp_get_attachment_image_src( $options['single_mobile_ad_image1'], 'full' ); ?>
  <div class="single_banner">
   <a href="<?php echo esc_url( $options['single_mobile_ad_url1'] ); ?>" target="_blank"><img src="<?php echo esc_attr($single_mobile_image[0]); ?>" alt="" title="" /></a>
  </div>
  <?php }; ?>
 </div><!-- END #single_banner_area_top -->
 <?php }; ?>
 <?php }; ?>

 <?php
      // mobile banner ------------------------------------------------------------------------------------------------------------------------
      if(is_mobile()) {
 ?>
 <?php if( $options['single_mobile_ad_code2'] || $options['single_mobile_ad_image2'] ) { ?>
 <div id="mobile_banner_bottom" class="single_banner_area one_banner">
  <?php if ($options['single_mobile_ad_code2']) { ?>
  <div class="single_banner">
   <?php echo $options['single_mobile_ad_code2']; ?>
  </div>
  <?php } else { ?>
  <?php $single_mobile_image = wp_get_attachment_image_src( $options['single_mobile_ad_image2'], 'full' ); ?>
  <div class="single_banner">
   <a href="<?php echo esc_url( $options['single_mobile_ad_url2'] ); ?>" target="_blank"><img src="<?php echo esc_attr($single_mobile_image[0]); ?>" alt="" title="" /></a>
  </div>
  <?php }; ?>
 </div><!-- END #single_banner_area_bottom -->
 <?php }; ?>
 <?php }; // END if mobile ?>

 <?php
       // related post ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      if ($options['show_related_post']){
        $categories = get_the_category($post->ID);
        if ($categories) {
          $category_ids = array();
          foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
          $num_post = $options['related_post_num'];
          $args = array( 'category__in' => $category_ids, 'post__not_in' => array($post->ID), 'showposts'=> $num_post, 'orderby' => 'rand');
          $blog_list = new wp_query($args);
          if($blog_list->have_posts()):
 ?>
 <div id="related_post">
  <?php if(!empty($options['related_headline'])) { ?>
  <h3 class="headline"><?php echo esc_html($options['related_headline']); ?></h3>
  <?php }; ?>
  <div class="post_list clearfix">
   <?php
        while( $blog_list->have_posts() ) : $blog_list->the_post();
          if(has_post_thumbnail()) {
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $blog_list->ID ), 'size1' );
          } elseif($options['no_image1']) {
            $image = wp_get_attachment_image_src( $options['no_image1'], 'full' );
          } else {
            $image[0] = esc_url(get_bloginfo('template_url')) . "/img/common/no_image1.gif";
          }
   ?>
   <article class="item">
    <a class="animate_background" style="background:none;" href="<?php the_permalink() ?>">
     <div class="image_wrap">
      <div class="image" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;"></div>
     </div>
     <p class="title rich_font"><span><?php the_title_attribute(); ?></span></p>
    </a>
   </article>
   <?php endwhile; wp_reset_query(); ?>
  </div><!-- END #post_list_type1 -->
 </div><!-- END #related_post -->
 <?php
         endif;
       };
     };
 ?>

 <?php
      // comment ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      if ($options['show_comment']) { comments_template('', true); };
 ?>

</div><!-- END #main_contents -->

<?php get_template_part('template-parts/single-widget'); ?>

<?php get_footer(); ?>
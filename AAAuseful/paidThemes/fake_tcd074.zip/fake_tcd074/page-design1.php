<?php
/*
Template Name:ABOUT Page
*/
__('ABOUT Page', 'tcd-w');
?>
<?php
     get_header();
     $options = get_design_plus_option();

     $desc = get_post_meta($post->ID, 'page_sub_title', true);
     $show_tab = get_post_meta($post->ID, 'show_tab', true);
     $tab_bg_blur = get_post_meta($post->ID, 'tab_bg_blur', true);
     $page_title_color = get_post_meta($post->ID, 'page_font_color', true);
     $page_bg_color = get_post_meta($post->ID, 'page_bg_color', true);
     $page_bg_image = get_post_meta($post->ID, 'page_bg_image', true);
     $page_bg_image_mobile = get_post_meta($post->ID, 'page_bg_image_mobile', true);
     $page_use_para = get_post_meta($post->ID, 'page_use_para', true);
     $use_overlay = get_post_meta($post->ID, 'page_use_overlay', true);
     if($use_overlay) {
       $overlay_color = hex2rgb(get_post_meta($post->ID, 'page_overlay_color', true));
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = get_post_meta($post->ID, 'page_overlay_opacity', true);
     }

     $page_content_order = get_post_meta($post->ID, 'page_content_order', true);
     if(empty($page_content_order)) {
       $page_content_order = array('content1','content2','content3','content4');
     }
?>
<div id="page_header" style="background:<?php echo esc_attr($page_bg_color); ?>;">
 <div id="page_header_catch" style="color:<?php echo esc_html($page_title_color); ?>;">
  <h2 class="catch rich_font animate_pc animate_mobile"><span><?php the_title(); ?></span></h2>
  <?php if($desc){ ?><p class="desc animate_pc animate_mobile"><span><?php echo nl2br(esc_html($desc)); ?></span></p><?php }; ?>
 </div>
 <?php
      // tab button
      if($show_tab){
 ?>
 <div id="tab_button_list">
  <div id="tab_button_list_inner">
   <ul>
    <?php
         foreach((array) $page_content_order as $page_content) :
           $i = preg_replace('/[^0-9]/', '', $page_content);
           $tab_name = get_post_meta($post->ID, 'design1_tab' . $i . '_name', true);
           $show_dc = get_post_meta($post->ID, 'show_design1_content'. $i, true);
    ?>
    <?php if( ($page_content == 'content'.$i) && $show_dc && $tab_name ) { ?><li><a href="#design_content_id<?php echo $i; ?>"><?php echo esc_html($tab_name); ?></a></li><?php }; ?>
    <?php endforeach; ?>
   </ul>
  </div>
  <?php if(($page_bg_image || $page_bg_image_mobile) && $tab_bg_blur) { ?>
  <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
  <div id="blur_bg" data-parallax-overlay-blur="<?php echo $tab_bg_blur; ?>"></div>
  <?php }; ?>
 </div>
 <?php }; // END tab button ?>
 <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
 <?php if($page_bg_image || $page_bg_image_mobile) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($page_bg_image)); ?>" data-parallax-mobile-image="<?php echo esc_attr(wp_get_attachment_url($page_bg_image_mobile)); ?>"<?php if ($page_use_para != 'type1') echo ' data-parallax-speed="0"'; ?>></div><?php }; ?>
</div>

<div id="design_page1">

 <?php
      if ( have_posts() ) : while ( have_posts() ) : the_post();
        if(!post_password_required( $post->ID )):

      // content1 -------------------------------------------------------
      $show_dc1 = get_post_meta($post->ID, 'show_design1_content1', true);

      $dc1_catch = get_post_meta($post->ID, 'design1_content1_catch', true);
      $dc1_desc = get_post_meta($post->ID, 'design1_content1_desc', true);

      $show_dc1_ic = get_post_meta($post->ID, 'show_design1_content1_ic', true);
      $dc1_ic_image_id = get_post_meta($post->ID, 'design1_content1_ic_image', true);
      $dc1_ic_use_para = get_post_meta($post->ID, 'design1_content1_ic_use_para', true);

      $dc1_ic_catch = get_post_meta($post->ID, 'design1_content1_ic_catch', true);
      $dc1_ic_title = get_post_meta($post->ID, 'design1_content1_ic_title', true);
      $dc1_ic_sub_title = get_post_meta($post->ID, 'design1_content1_ic_sub_title', true);

      $dc1_ic_content_direction = get_post_meta($post->ID, 'design1_content1_ic_content_direction', true);

      $dc1_ic_font_color = get_post_meta($post->ID, 'design1_content1_ic_font_color', true);

      $dc1_ic_use_overlay = get_post_meta($post->ID, 'design1_content1_ic_use_overlay', true);
      if($dc1_ic_use_overlay) {
        $dc1_ic_overlay_color = hex2rgb(get_post_meta($post->ID, 'design1_content1_ic_overlay_color', true));
        $dc1_ic_overlay_color = implode(",",$dc1_ic_overlay_color);
        $dc1_ic_overlay_opacity = get_post_meta($post->ID, 'design1_content1_ic_overlay_opacity', true);
      };

      // content2 -------------------------------------------------------
      $show_dc2 = get_post_meta($post->ID, 'show_design1_content2', true);

      $dc2_catch = get_post_meta($post->ID, 'design1_content2_catch', true);
      $dc2_desc = get_post_meta($post->ID, 'design1_content2_desc', true);
      $dc2_desc2 = get_post_meta($post->ID, 'design1_content2_desc2', true);
      $dc2_image_id = get_post_meta($post->ID, 'design1_content2_image', true);
      if($dc2_image_id){
        $dc2_image = wp_get_attachment_image_src($dc2_image_id, 'full');
      }

      $dc2_data_list = get_post_meta($post->ID, 'design1_content2_data_list', true);

      $show_dc2_ic = get_post_meta($post->ID, 'show_design1_content2_ic', true);
      $dc2_ic_image_id = get_post_meta($post->ID, 'design1_content2_ic_image', true);
      $dc2_ic_use_para = get_post_meta($post->ID, 'design1_content2_ic_use_para', true);

      $dc2_ic_catch = get_post_meta($post->ID, 'design1_content2_ic_catch', true);
      $dc2_ic_title = get_post_meta($post->ID, 'design1_content2_ic_title', true);
      $dc2_ic_sub_title = get_post_meta($post->ID, 'design1_content2_ic_sub_title', true);

      $dc2_ic_content_direction = get_post_meta($post->ID, 'design1_content2_ic_content_direction', true);

      $dc2_ic_font_color = get_post_meta($post->ID, 'design1_content2_ic_font_color', true);

      $dc2_ic_use_overlay = get_post_meta($post->ID, 'design1_content2_ic_use_overlay', true);
      if($dc2_ic_use_overlay) {
        $dc2_ic_overlay_color = hex2rgb(get_post_meta($post->ID, 'design1_content2_ic_overlay_color', true));
        $dc2_ic_overlay_color = implode(",",$dc2_ic_overlay_color);
        $dc2_ic_overlay_opacity = get_post_meta($post->ID, 'design1_content2_ic_overlay_opacity', true);
      };

      // content3 -------------------------------------------------------
      $show_dc3 = get_post_meta($post->ID, 'show_design1_content3', true);

      $dc3_headline = get_post_meta($post->ID, 'design1_content3_headline', true);

      $dc3_data_list = get_post_meta($post->ID, 'design1_content3_data_list', true);

      // content4 -------------------------------------------------------
      $show_dc4 = get_post_meta($post->ID, 'show_design1_content4', true);

      $dc4_headline = get_post_meta($post->ID, 'design1_content4_headline', true);

      $access_address = get_post_meta($post->ID, 'access_address', true);
      $access_saturation = get_post_meta($post->ID, 'access_saturation', true);
      $use_custom_overlay = 'type2' === $options['gmap_marker_type'] ? 1 : 0;
      $marker_img = $options['gmap_marker_img'] ? wp_get_attachment_url( $options['gmap_marker_img'] ) : '';
      $marker_text = $options['gmap_marker_text'];

      $access_logo_image = get_post_meta($post->ID, 'access_logo_image', true);
      $access_logo_retina = get_post_meta($post->ID,'access_logo_retina',true);
      $access_desc1 = get_post_meta($post->ID, 'access_desc1', true);
      $access_desc2 = get_post_meta($post->ID, 'access_desc2', true);

      $show_access_button = get_post_meta($post->ID, 'show_access_button', true);
      $access_button_label = get_post_meta($post->ID, 'access_button_label', true);
      $access_button_url = get_post_meta($post->ID, 'access_button_url', true);

      // START content order
      foreach((array) $page_content_order as $page_content) :
 ?>

  <?php
       // content1 -----------------------------------------------------------------------
       if( ($page_content == 'content1') && $show_dc1) {
  ?>
  <div class="design_content" id="design_content_id1">

   <?php
        // catch and desc
        if($dc1_catch || $dc1_desc){
   ?>
   <div class="dc_content">
    <?php if($dc1_catch){ ?>
    <h3 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($dc1_catch)); ?></span></h3>
    <?php }; ?>
    <?php if($dc1_desc) { ?>
    <div class="post_content clearfix">
     <?php echo do_shortcode( wpautop(wp_kses_post($dc1_desc)) ); ?>
    </div>
    <?php }; ?>
   </div><!-- END .dc_content -->
   <?php }; ?>

   <?php
        // image_content
        if($show_dc1_ic && $dc1_ic_image_id){
   ?>
   <div class="dc_image_content">
    <div class="dc_image_content_inner direction_<?php echo esc_attr($dc1_ic_content_direction); ?>">
     <?php if($dc1_ic_catch || $dc1_ic_title){ ?>
     <div class="caption" style="color:<?php echo esc_attr($dc1_ic_font_color); ?>;">
      <?php if($dc1_ic_catch){ ?>
      <h4 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($dc1_ic_catch)); ?></span></h4>
      <?php }; ?>
      <?php if($dc1_ic_title) { ?>
      <p class="title"><?php if($dc1_ic_sub_title) { echo '<span>' . esc_html($dc1_ic_sub_title) . '</span>'; }; ?><?php echo wp_kses_post(nl2br($dc1_ic_title)); ?></p>
      <?php }; ?>
     </div>
     <?php }; ?>
    </div>
    <?php if($dc1_ic_use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($dc1_ic_overlay_color); ?>,<?php echo esc_html($dc1_ic_overlay_opacity); ?>);"></div><?php }; ?>
    <?php if($dc1_ic_image_id) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($dc1_ic_image_id)); ?>" data-parallax-mobile-image=""<?php if ($dc1_ic_use_para != 'type1') echo ' data-parallax-speed="0"'; ?>></div><?php }; ?>
   </div><!-- END .dc_image_content -->
   <?php }; ?>

  </div><!-- END #design_content_id1 -->
  <?php }; ?>

  <?php
       // content2 -----------------------------------------------------------------------
       if( ($page_content == 'content2') && $show_dc2) {
  ?>
  <div class="design_content" id="design_content_id2">

   <?php
        // catch, desc, image, desc2, data list
        if($dc2_catch || $dc2_desc || $dc2_image_id || $dc2_des2 || $dc2_data_list){
   ?>
   <div class="dc_content">
    <?php if($dc2_catch){ ?>
    <h3 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($dc2_catch)); ?></span></h3>
    <?php }; ?>
    <?php if($dc2_desc) { ?>
    <div class="post_content clearfix">
     <?php echo do_shortcode( wpautop(wp_kses_post($dc2_desc)) ); ?>
    </div>
    <?php }; ?>
    <?php if($dc2_image_id){ ?>
    <img class="dc_image" src="<?php echo esc_attr($dc2_image[0]); ?>" alt="" title="" />
    <?php }; ?>
    <?php if($dc2_desc2) { ?>
    <div class="post_content clearfix">
     <?php echo do_shortcode( wpautop(wp_kses_post($dc2_desc2)) ); ?>
    </div>
    <?php }; ?>
    <?php if($dc2_data_list){ ?>
    <div class="dc_message_list">
     <?php $i = 1 ;foreach ( $dc2_data_list as $key => $value ) : ?>
     <div class="item item<?php echo $i; ?>" style="background:<?php echo esc_attr($value['bg_color']); ?>;">
      <?php if($value['catch']) { ?>
      <p class="catch rich_font"><span><?php echo wp_kses_post(nl2br($value['catch'])); ?></span></p>
      <?php }; ?>
     </div>
     <?php $i++; endforeach; ?>
    </div>
    <?php }; ?>
   </div><!-- END .dc_content -->
   <?php }; ?>

   <?php
        // image_content
        if($show_dc2_ic && $dc2_ic_image_id){
   ?>
   <div class="dc_image_content">
    <div class="dc_image_content_inner direction_<?php echo esc_attr($dc2_ic_content_direction); ?>">
     <?php if($dc2_ic_catch || $dc2_ic_title){ ?>
     <div class="caption" style="color:<?php echo esc_attr($dc2_ic_font_color); ?>;">
      <?php if($dc2_ic_catch){ ?>
      <h4 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($dc2_ic_catch)); ?></span></h4>
      <?php }; ?>
      <?php if($dc2_ic_title) { ?>
      <p class="title"><?php if($dc2_ic_sub_title) { echo '<span>' . esc_html($dc2_ic_sub_title) . '</span>'; }; ?><?php echo wp_kses_post(nl2br($dc2_ic_title)); ?></p>
      <?php }; ?>
     </div>
     <?php }; ?>
    </div>
    <?php if($dc2_ic_use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($dc2_ic_overlay_color); ?>,<?php echo esc_html($dc2_ic_overlay_opacity); ?>);"></div><?php }; ?>
    <?php if($dc2_ic_image_id) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($dc2_ic_image_id)); ?>" data-parallax-mobile-image=""<?php if ($dc2_ic_use_para != 'type1') echo ' data-parallax-speed="0"'; ?>></div><?php }; ?>
   </div><!-- END .dc_image_content -->
   <?php }; ?>

  </div><!-- END #design_content_id2 -->
  <?php }; ?>

  <?php
       // content3 -----------------------------------------------------------------------
       if( ($page_content == 'content3') && $show_dc3) {
  ?>
  <div class="design_content" id="design_content_id3">

   <?php
        // data list
        if($dc3_headline || $dc3_data_list){
   ?>
   <div class="dc_data_list">
    <?php if($dc3_headline){ ?>
    <h3 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($dc3_headline)); ?></span></h3>
    <?php }; ?>
    <dl class="clearfix">
     <?php foreach ( $dc3_data_list as $key => $value ) : ?>
     <dt><span><?php if(!empty($value['title'])) { echo wp_kses_post(nl2br($value['title'])); }; ?></span></dt>
     <dd><span><?php if(!empty($value['desc'])) { echo wp_kses_post(nl2br($value['desc'])); }; ?></span></dd>
     <?php endforeach; ?>
    </dl>
   </div>
   <?php }; ?>

  </div><!-- END #design_content_id3 -->
  <?php }; ?>

  <?php
       // content4 -----------------------------------------------------------------------
       if( ($page_content == 'content4') && $show_dc4) {
  ?>
  <div class="design_content" id="design_content_id4">

   <div id="access_info">

    <?php if($dc4_headline){ ?>
    <h3 class="catch rich_font"><span><?php echo wp_kses_post(nl2br($dc4_headline)); ?></span></h3>
    <?php }; ?>

    <?php if ($access_address){ ?>

    <div id="access_google_map">
     <div class="pb_googlemap clearfix">
      <div id="dc_google_map" class="pb_googlemap_embed"></div>
     </div><!-- END .pb_googlemap -->
     <script>
       jQuery(function($) {
         $(window).load(function() {
           initMap('dc_google_map', '<?php echo esc_js( $access_address ); ?>', <?php echo esc_js( $access_saturation ); ?>, <?php echo esc_js( $use_custom_overlay ); ?>, '<?php echo esc_js( $marker_img ); ?>', '<?php echo esc_js( $marker_text ); ?>');
         });
       });
     </script>
    </div><!-- END #access_google_map -->

    <?php if($access_logo_image || $access_desc1 || $show_access_button || $access_desc2) { ?>
    <div id="access_data">
     <?php if($access_logo_image || $access_desc1) { ?>
     <div class="top_area">
      <?php
           if(!empty($access_logo_image)) {
             $image = wp_get_attachment_image_src($access_logo_image, 'full');
             $image_width = $image[1];
             $image_height = $image[2];
             if($access_logo_retina) {
               $image_width = round($image_width / 2);
               $image_height = round($image_height / 2);
             };
      ?>
      <img class="logo" src="<?php echo esc_attr($image[0]); ?>" alt="" title="" width="<?php echo esc_attr($image_width); ?>" height="<?php echo esc_attr($image_height); ?>" />
      <?php }; ?>
      <?php if($access_desc1){ ?>
      <p class="desc desc1"><?php echo wp_kses_post(nl2br($access_desc1)); ?></p>
      <?php }; ?>
     </div>
     <?php }; ?>
     <?php if($show_access_button || $access_desc2) { ?>
     <div class="bottom_area">
      <?php if($access_button_url) { ?>
      <div class="link_button">
       <a href="<?php echo esc_url($access_button_url); ?>" target="_blank"><span><?php echo esc_html($access_button_label); ?></span></a>
      </div>
      <?php }; ?>
      <?php if($access_desc2){ ?>
      <p class="desc desc2"><?php echo wp_kses_post(nl2br($access_desc2)); ?></p>
      <?php }; ?>
     </div>
     <?php }; ?>
    </div><!-- END #access_data -->
    <?php }; ?>

    <?php }; // if $access_addresss ?>

   </div><!-- #access_info -->

  </div><!-- END #design_content_id4 -->
  <?php }; ?>

  <?php endforeach; // END contet order ?>

  <?php else: ?>
  <div class="dc_content">
  <?php the_content();
    custom_wp_link_pages();
  ?>
  </div>
  <?php endif; // END post_password_required ?>

 <?php endwhile; endif; ?>

</div><!-- END #design_page -->

<?php get_footer(); ?>
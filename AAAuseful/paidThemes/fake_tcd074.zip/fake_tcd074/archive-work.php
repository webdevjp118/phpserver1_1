<?php
     get_header();
     $options = get_design_plus_option();

     $catch = $options['work_catch'];
     $desc = $options['work_desc'];
     $show_category = $options['show_work_list_category'];

     $use_overlay = $options['work_use_overlay'];
     if($use_overlay) {
       $overlay_color = hex2rgb($options['work_overlay_color']);
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = $options['work_overlay_opacity'];
     }
?>
<div id="page_header" style="background:<?php echo esc_attr($options['work_bg_color']); ?>;">
 <div id="page_header_catch">
  <?php if($catch){ ?><h2 class="catch rich_font animate_pc animate_mobile"><span><?php echo wp_kses_post(nl2br($catch)); ?></span></h2><?php }; ?>
  <?php if($desc){ ?><p class="desc animate_pc animate_mobile"><span><?php echo nl2br(esc_html($desc)); ?></span></p><?php }; ?>
 </div>
 <?php
      // tab button
      $landmark_category = get_terms( 'landmark', array( 'hide_empty' => true, 'orderby' => 'id', 'parent' => 0 ) );
      if ( $landmark_category && ! is_wp_error($landmark_category) ) {
        if($options['show_archive_work_tab']){
 ?>
 <div id="tab_button_list">
  <div id="tab_button_list_inner">
   <ul class="clearfix">
    <?php foreach ( $landmark_category as $landmark_cat ): ?>
    <li><a href="#work_area_cat_id<?php echo esc_html($landmark_cat->term_id); ?>"><?php echo esc_html($landmark_cat->name); ?></a></li>
    <?php endforeach; ?>
   </ul>
  </div>
  <?php if(($options['work_bg_image'] || $options['work_bg_image_mobile']) && $options['archive_work_tab_bg_blur']) { ?>
  <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
  <div id="blur_bg" data-parallax-overlay-blur="<?php echo absint($options['archive_work_tab_bg_blur']); ?>"></div>
  <?php }; ?>
 </div>
 <?php
        };
      }; // END tab button
 ?>
 <?php if($use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
 <?php if($options['work_bg_image'] || $options['work_bg_image_mobile']) { ?><div class="bg_image" data-parallax-image="<?php echo esc_attr(wp_get_attachment_url($options['work_bg_image'])); ?>" data-parallax-mobile-image="<?php echo esc_attr(wp_get_attachment_url($options['work_bg_image_mobile'])); ?>" data-parallax-speed="0"></div><?php }; ?>
</div>

<div id="archive_work">

 <?php
      if ( $landmark_category && ! is_wp_error($landmark_category) ) {
         foreach ( $landmark_category as $landmark_cat ):
           $num = 1;
           $landmark_cat_id = $landmark_cat->term_id;
           $custom_fields = get_option( 'taxonomy_' . $landmark_cat_id, array() );
 ?>
 <div class="work_area" id="work_area_cat_id<?php echo esc_html($landmark_cat_id); ?>">

  <div class="work_area_top">
   <h3 class="headline rich_font scroll_effect"><?php echo esc_html($landmark_cat->name); ?></h3>
   <?php if (!empty($custom_fields['desc'])){ ?>
   <p class="desc scroll_effect"><?php echo wp_kses_post(nl2br($custom_fields['desc'])); ?></p>
   <?php }; ?>
  </div>

  <?php
       // area category list ---------------
       if($options['show_archive_work_button']){
         $area_category_ids = array();
         $args = array( 'post_type' => 'work', 'posts_per_page' => -1, 'tax_query' => array( array( 'taxonomy' => 'landmark', 'field' => 'term_id', 'terms' => $landmark_cat_id ) ) );
         $work_query = new wp_query($args);
         if($work_query->have_posts()):
           while($work_query->have_posts()): $work_query->the_post();
             $area_category = get_the_terms( $post->ID, 'area' );
             if ( $area_category && ! is_wp_error( $area_category ) ) :
               foreach ( $area_category as $area_cat ) :
                 $area_category_id = $area_cat->term_id;
               endforeach;
             endif;
             array_push($area_category_ids, $area_category_id);
           endwhile;
         endif;
         $area_category_ids = array_unique($area_category_ids);
         $area_category_ids = array_values($area_category_ids);
  ?>
  <div class="child_category_list scroll_effect">
   <h3 class="headline"><?php echo esc_html($options['archive_work_button_label']); ?></h3>
   <div class="sort_button">
    <ul class="clearfix filter">
     <li><a href="#" class="active" data-filter="all"><?php _e( 'ALL', 'tcd-w' ); ?></a></li>
     <?php
          foreach ( $area_category_ids as $area_category_id ):
            $area_data = get_term_by( 'id', $area_category_id, 'area' );
            $name = $area_data->name;
     ?>
     <li><a href="#" data-filter="cat_id<?php echo esc_attr($area_category_id); ?>"><?php echo esc_html($name); ?></a></li>
     <?php endforeach; ?>
    </ul>
   </div>
  </div>
  <?php }; ?>

  <div class="post_list_area scroll_effect">
   <?php
        // work list --------------------
        $args = array( 'post_type' => 'work', 'posts_per_page' => -1, 'tax_query' => array( array( 'taxonomy' => 'landmark', 'field' => 'term_id', 'terms' => $landmark_cat_id ) ) );
        $work_query = new wp_query($args);
        if($work_query->have_posts()):
   ?>
   <div class="work_list clearfix animation_<?php echo esc_attr($options['archive_work_list_animation_type']); ?>">
    <?php
         while($work_query->have_posts()): $work_query->the_post();
           if(has_post_thumbnail()) {
             $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'size1' );
           } elseif($options['no_image2']) {
             $image = wp_get_attachment_image_src( $options['no_image1'], 'full' );
           } else {
             $image = array();
             $image[0] = esc_url(get_bloginfo('template_url')) . "/img/common/no_image1.gif";
           }
           $area_category = get_the_terms( $post->ID, 'area' );
           $area_name = '';
           $area_id = '';
           if ( $area_category && ! is_wp_error($area_category) ) {
             foreach ( $area_category as $area_cat ) :
               $area_name = $area_cat->name;
               $area_id = $area_cat->term_id;
               break;
             endforeach;
           };
    ?>
    <article class="item" data-category="cat_id<?php echo esc_attr($area_id); ?>">
     <a class="link animate_background" style="background:none;" href="<?php the_permalink() ?>">
      <div class="image_wrap">
       <div class="image_wrap_inner">
        <?php if ($show_category && $area_name) { ?>
        <div class="category">
         <span><?php echo esc_html($area_name); ?></span>
        </div>
        <?php }; ?>
        <div class="image" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;"></div>
       </div>
      </div>
      <h3 class="title"><span><?php the_title(); ?></span></h3>
     </a>
    </article>
    <?php endwhile; ?>
   </div><!-- END .work_list -->
   <?php endif; wp_reset_query(); ?>

  </div><!-- END .post_list_area -->

 </div><!-- END .work_area -->

 <?php
        $num++;
        endforeach;
      }; // has landmark category
 ?>

</div><!-- END #archive_work -->

<?php get_footer(); ?>
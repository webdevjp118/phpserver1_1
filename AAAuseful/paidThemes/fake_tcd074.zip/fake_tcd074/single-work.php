<?php
     get_header();
     $options = get_design_plus_option();
     $title = $options['work_label'];
     $image_id = $options['work_bg_image'];
     if(!empty($image_id)) {
       $image = wp_get_attachment_image_src($image_id, 'full');
       if(is_mobile()) {
         $image_mobile = wp_get_attachment_image_src( $options['work_bg_image_mobile'], 'full');
         if($image_mobile) {
           $image = $image_mobile;
         };
       }
     } else {
       $background_color = $options['work_bg_color'];
     }
     $use_overlay = $options['work_use_overlay'];
     if($use_overlay) {
       $overlay_color = hex2rgb($options['work_overlay_color']);
       $overlay_color = implode(",",$overlay_color);
       $overlay_opacity = $options['work_overlay_opacity'];
     }
     // landmark data
     $args = array( 'orderby' => 'term_order' );
     $landmark_category = wp_get_post_terms( $post->ID, 'landmark' ,$args);
     if ( $landmark_category && ! is_wp_error($landmark_category) ) {
       foreach ( $landmark_category as $landmark_cat ) :
         $landmark_cat_name = $landmark_cat->name;
         $landmark_cat_id = $landmark_cat->term_id;
         break;
       endforeach;
       // overwrite the data if category data exist
       $term_meta = get_option( 'taxonomy_' . $landmark_cat_id, array() );
       if (!empty($term_meta['image'])){
         $image_id = $term_meta['image'];
         $image = wp_get_attachment_image_src( $image_id, 'full' );
         if(is_mobile()) {
           if (!empty($term_meta['image_mobile'])){
             $image_id = $term_meta['image_mobile'];
             $image = wp_get_attachment_image_src( $image_id, 'full' );
           }
         }
       }
     }; // end landmark data
     if (!empty($term_meta['use_overlay'])){
       if (!empty($term_meta['overlay_color'])){
         $overlay_color = hex2rgb($term_meta['overlay_color']);
         $overlay_color = implode(",",$overlay_color);
         if (!empty($term_meta['overlay_opacity'])){
           $overlay_opacity = $term_meta['overlay_opacity'];
         } else {
           $overlay_opacity = '0.3';
         }
       }
     }
?>
<?php if(!empty($image_id)) { ?>
<div id="page_header" class="small" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center top; background-size:cover;">
<?php } else { ?>
<div id="page_header" class="small" style="background:<?php echo $background_color; ?>;">
<?php }; ?>
 <?php if($image_id && $use_overlay) { ?><div class="overlay" style="background:rgba(<?php echo esc_html($overlay_color); ?>,<?php echo esc_html($overlay_opacity); ?>);"></div><?php }; ?>
</div>

<?php get_template_part('template-parts/breadcrumb'); ?>

<div id="single_work_title_area">
 <?php if($options['show_work_category']) { ?>
 <ul class="category clearfix">
  <?php if ( $landmark_category && ! is_wp_error($landmark_category) ) { ?>
  <li class="parent"><a href="<?php echo esc_url(get_category_link($landmark_cat_id)); ?>"><?php echo esc_html($landmark_cat_name); ?></a></li>
  <?php }; ?>
  <?php
       $area_category = get_the_terms( $post->ID, 'area' );
       if ( $area_category && ! is_wp_error($area_category) ) {
         foreach ( $area_category as $area_cat ) :
           $area_name = $area_cat->name;
           $area_id = $area_cat->term_id;
           $area_custom_fields = get_option( 'taxonomy_' . $area_id, array() );
           if (!empty($area_custom_fields['color'])){
             $area_category_color = $area_custom_fields['color'];
           } else {
             $area_category_color = '#a33f37';
           }
         endforeach;
  ?>
  <li class="child"><a href="<?php echo esc_url(get_category_link($area_id)); ?>"><?php echo esc_html($area_name); ?></a></li>
  <?php }; ?>
 </ul>
 <?php }; ?>
 <h1 class="title rich_font entry-title"><?php the_title(); ?></h1>
</div>

<div id="main_contents" class="clearfix">

 <?php
      if ( have_posts() ) : while ( have_posts() ) : the_post();
 ?>

 <article id="article">

<?php
        // Contents builder
        $work_contents_builder = get_post_meta( $post->ID, 'work_contents_builder', true );

        if ( $work_contents_builder && is_array( $work_contents_builder ) ) :
          foreach( $work_contents_builder as $key => $content ) :
            if ( empty( $content['content_select'] ) || empty( $content['display'] ) ) continue;

            if ( 'text_and_images' === $content['content_select'] ) :
              if ( ! empty( $content['catch'] ) || ! empty( $content['desc'] ) || ( ! empty( $content['images'] ) && is_array( $content['images'] ) ) ) :
?>
  <div class="work_content work_content_<?php echo esc_attr( $key + 1 ); ?>">
<?php
                if ( ! empty( $content['catch'] ) ) :
?>
   <h3 class="single_work_catch rich_font"><span><?php echo wp_kses_post( nl2br( $content['catch'] ) ); ?></span></h3>
<?php
                endif;
                if ( ! empty( $content['desc'] ) ) :
?>
   <div class="single_work_desc post_content clearfix">
    <?php echo apply_filters( 'the_content', $content['desc'] ); ?>
   </div>
<?php
                endif;
                if ( ! empty( $content['images'] ) && is_array( $content['images'] ) ) :
?>
   <div class="single_work_image_list clearfix">
<?php
                  $type2_count = 0;
                  foreach ( $content['images'] as $repeater_key => $repeater_value ) :
                    if ( empty( $repeater_value['image'] ) ) continue;
                    $image = wp_get_attachment_image_src( $repeater_value['image'],  'size3' );
                    if ( ! $image ) continue;

                    if ( isset( $repeater_value['size'] ) && 'type2' === $repeater_value['size'] ) :
                      $img_class = 'small';
                      $type2_count++;
                      if ( 0 === $type2_count % 2) :
                        $img_class .= ' even';
                      else :
                        $img_class .= ' odd';
                      endif;
                    else :
                      $img_class = 'large';
                      $type2_count = 0;
                    endif;
?>
    <img class="<?php echo $img_class; ?>" src="<?php echo esc_attr( $image[0] ); ?>" alt="" title="" />
<?php
                  endforeach;
?>
   </div>
<?php
                endif;
?>
  </div>
<?php
              endif;

            elseif( 'data_list' === $content['content_select'] ) :
              if ( ! empty( $content['catch'] ) || ( ! empty( $content['datas'] ) && is_array( $content['datas'] ) ) || ( ! empty( $content['show_button'] ) && ! empty( $content['button_label'] ) ) ) :
?>
  <div class="work_content work_content_<?php echo esc_attr( $key + 1 ); ?>">
<?php
                if ( ! empty( $content['catch'] ) ) :
?>
   <h3 class="single_work_catch rich_font"><span><?php echo wp_kses_post( nl2br( $content['catch'] ) ); ?></span></h3>
<?php
                endif;

                if ( ( ! empty( $content['datas'] ) && is_array( $content['datas'] ) ) || ( ! empty( $content['show_button'] ) && ! empty( $content['button_label'] ) ) ) :
?>
   <div class="work_data_list">
<?php
                  if ( ! empty( $content['datas'] ) && is_array( $content['datas'] ) ) :
?>
    <dl class="clearfix">
<?php
                    foreach ( $content['datas'] as $repeater_key => $repeater_value ) :
?>
     <dt><span><?php if ( ! empty( $repeater_value['title'] ) ) echo wp_kses_post( nl2br( $repeater_value['title'] ) ); ?></span></dt>
     <dd><span><?php if ( ! empty( $repeater_value['desc'] ) ) echo wp_kses_post( nl2br( $repeater_value['desc'] ) ); ?></span></dt>
<?php
                    endforeach;
?>
    </dl>
<?php
                  endif;
                  if ( ! empty( $content['show_button'] ) && ! empty( $content['button_label'] ) ) :
?>
    <div class="link_button">
     <a href="<?php echo esc_url( $content['button_url'] ); ?>"<?php if ( ! empty( $content['button_target_blank'] ) ) echo ' target="_blank"'; ?>><?php echo esc_html( $content['button_label'] ); ?></a>
    </div>
<?php
                  endif;
?>
   </div>
<?php
                endif;
?>
  </div>
<?php
              endif;
            endif;
          endforeach;
        endif;
?>

  <?php
       // page nav ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       if ($options['show_work_nav']) :
  ?>
  <div id="next_prev_post2" class="clearfix">
   <?php work_next_prev_post_link(); ?>
  </div>
  <?php endif; ?>

 </article><!-- END #article -->

 <?php endwhile; endif; ?>

 <?php
       // related post ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      if ($options['show_related_work'] && $landmark_category){
        $show_category = $options['show_work_list_category'];
        $post_num = $options['related_work_post_num'];
        $args = array( 'post_type' => 'work', 'posts_per_page' => $post_num, 'tax_query' => array( array( 'taxonomy' => 'landmark', 'field' => 'term_id', 'terms' => $landmark_cat_id ) ) );
        $work_query = new wp_query($args);
        if($work_query->have_posts()):
 ?>
 <div id="related_work_list">
  <?php if($landmark_cat_name) { ?>
  <h3 class="headline"><?php echo esc_html($landmark_cat_name); ?></h3>
  <?php }; ?>
  <div class="work_list clearfix">
   <?php
        while($work_query->have_posts()): $work_query->the_post();
          if(has_post_thumbnail()) {
            $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'size1' );
          } elseif($options['no_image2']) {
            $image = wp_get_attachment_image_src( $options['no_image1'], 'full' );
          } else {
            $image = array();
            $image[0] = esc_url(get_bloginfo('template_url')) . "/img/common/no_image1.gif";
          }
   ?>
   <article class="item">
    <a class="link animate_background" style="background:none;" href="<?php the_permalink() ?>">
     <div class="image_wrap">
      <div class="image_wrap_inner">
       <?php
            if ($show_category) {
             $area_category = get_the_terms( $post->ID, 'area' );
               if ( $area_category && ! is_wp_error($area_category) ) {
       ?>
       <div class="category">
        <?php
             foreach ( $area_category as $area_cat ) :
               echo "<span>" . esc_html($area_cat->name) . "</span>";
               break;
             endforeach;
        ?>
       </div>
       <?php }; }; ?>
       <div class="image" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;"></div>
      </div>
     </div>
     <h3 class="title"><span><?php the_title(); ?></span></h3>
    </a>
   </article>
   <?php endwhile; ?>
  </div><!-- END .work_list -->
  <?php endif; wp_reset_query(); ?>
 </div><!-- END #related_post -->
 <?php }; ?>

</div><!-- END #main_contents -->

<?php get_footer(); ?>
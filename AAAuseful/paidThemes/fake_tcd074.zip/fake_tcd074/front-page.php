<?php
     $options = get_design_plus_option();
     get_header();
     if (!empty($options['contents_builder'])) :
       $content_count = 1;
       foreach($options['contents_builder'] as $content) :
         // content1 --------------------------------------------------------------------------------
         if ($content['cb_content_select'] == 'content1') {
           $catch = $content['content1_catch'];
           $desc1 = $content['content1_desc1'];
           $desc2 = $content['content1_desc2'];
           $show_button = $content['content1_show_button'];
           $button_label = $content['content1_button_label'];
           $button_url = $content['content1_button_url'];
           $image1_id = $content['content1_image1'];
           if(!empty($image1_id)) {
             $image1 = wp_get_attachment_image_src($image1_id, 'full');
           }
           $image2_id = $content['content1_image2'];
           if(!empty($image2_id)) {
             $image2 = wp_get_attachment_image_src($image2_id, 'full');
           }
           $image3_id = $content['content1_image3'];
           if(!empty($image3_id)) {
             $image3 = wp_get_attachment_image_src($image3_id, 'full');
           }
?>
<div class="index_content1 cb_contents num<?php echo $content_count; ?>">
 <?php if($catch) { ?>
 <h2 class="catch rich_font"><span><?php echo nl2br(esc_html($catch)); ?></span></h2>
 <?php }; ?>
 <?php if($desc1) { ?>
 <p class="desc"><span><?php echo nl2br(esc_html($desc1)); ?></span></p>
 <?php }; ?>
 <?php if($image1_id || $image2_id || $image3_id) { ?>
 <div class="image_list clearfix">
  <?php if($image1_id) { ?><img src="<?php echo esc_attr($image1[0]); ?>" title="" alt=""><?php }; ?>
  <?php if($image2_id) { ?><img src="<?php echo esc_attr($image2[0]); ?>" title="" alt=""><?php }; ?>
  <?php if($image3_id) { ?><img src="<?php echo esc_attr($image3[0]); ?>" title="" alt=""><?php }; ?>
 </div>
 <?php }; ?>
 <?php if($desc2) { ?>
 <p class="desc"><span><?php echo nl2br(esc_html($desc2)); ?></span></p>
 <?php }; ?>
 <?php if( $show_button && $button_url && $button_label) { ?>
 <div class="link_button">
  <a href="<?php echo esc_url($button_url); ?>"><span><?php echo esc_html($button_label); ?></span></a>
 </div>
 <?php }; ?>
</div><!-- END .cb_contents -->
<?php
         // content2 --------------------------------------------------------------------------------
         } elseif ($content['cb_content_select'] == 'content2') {
           $catch = $content['content2_catch'];
           $catch2 = $content['content2_catch2'];
           $desc1 = $content['content2_desc1'];
           $desc2 = $content['content2_desc2'];
           $show_button1 = $content['content2_show_button1'];
           $button_label1 = $content['content2_button1_label'];
           $button_url1 = $content['content2_button1_url'];
           $show_button2 = $content['content2_show_button2'];
           $button_label2 = $content['content2_button2_label'];
           $button_url2 = $content['content2_button2_url'];
           $image_id = $content['content2_image'];
           if(!empty($image_id)) {
             $image = wp_get_attachment_image_src($image_id, 'full');
           }
           $use_overlay = $content['content2_use_overlay'];
?>
<div class="index_content2 cb_contents num<?php echo $content_count; ?>">
 <?php if($catch) { ?>
 <h2 class="catch rich_font"><span><?php echo nl2br(esc_html($catch)); ?></span></h2>
 <?php }; ?>
 <?php if($desc1) { ?>
 <p class="desc"><span><?php echo nl2br(esc_html($desc1)); ?></span></p>
 <?php }; ?>
 <?php if($image_id) { ?>
 <div class="image_content" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;">
  <?php if($catch2) { ?>
  <h2 class="catch rich_font"><span><?php echo nl2br(esc_html($catch2)); ?></span></h2>
  <?php }; ?>
  <?php if( $show_button1 && $button_url1 && $button_label1) { ?>
  <div class="link_button">
   <a href="<?php echo esc_url($button_url1); ?>"><span><?php echo esc_html($button_label1); ?></span></a>
  </div>
  <?php }; ?>
  <?php if($use_overlay) { ?>
  <div class="overlay"></div>
  <?php }; ?>
 </div>
 <?php }; ?>
 <?php if($desc2) { ?>
 <p class="desc"><span><?php echo nl2br(esc_html($desc2)); ?></span></p>
 <?php }; ?>
 <?php if( $show_button2 && $button_url2 && $button_label2) { ?>
 <div class="link_button">
  <a href="<?php echo esc_url($button_url2); ?>"><span><?php echo esc_html($button_label2); ?></span></a>
 </div>
 <?php }; ?>
</div><!-- END .cb_contents -->
<?php
         // parallax --------------------------------------------------------------------------------
         } elseif ($content['cb_content_select'] == 'para_content') {
           $catch = $content['para_content_catch'];
           $desc = $content['para_content_desc'];
           $image_id = $content['para_content_image'];
           if(!empty($image_id)) {
             $image = wp_get_attachment_image_src($image_id, 'full');
           }
           $use_overlay = $content['para_content_use_overlay'];
           if($image_id) {
?>
<div class="index_parallax parallax num<?php echo $content_count; ?> direction_<?php echo esc_attr($content['para_content_direction']); ?>">
 <?php if( $catch || $desc) { ?>
 <div class="caption">
  <?php if($catch) { ?>
  <h2 class="catch rich_font"><span><?php echo nl2br(esc_html($catch)); ?></span></h2>
  <?php }; ?>
  <?php if($desc) { ?>
  <p class="desc"><span><?php echo nl2br(esc_html($desc)); ?></span></p>
  <?php }; ?>
 </div>
 <?php }; ?>
 <?php if($use_overlay) { ?>
 <div class="overlay"></div>
 <?php }; ?>
 <div class="bg_image" data-parallax-image="<?php echo esc_attr($image[0]); ?>"></div>
</div><!-- END .index_parallax -->
<?php
           };
         // work list --------------------------------------------------------------------------------
         } elseif ($content['cb_content_select'] == 'post_list') {
           $post_num = $content['post_list_num'];
           $show_category = $options['show_work_list_category'];
           $show_button = $content['post_list_show_button'];
           $button_label = $content['post_list_button_label'];
           $work_query = new WP_Query('post_type=work&posts_per_page='.$post_num);
           if ($work_query->have_posts()) :
?>
<div class="index_work_list cb_contents num<?php echo $content_count; ?>">
 <div class="work_list clearfix">
  <?php
       while($work_query->have_posts()): $work_query->the_post();
         if(has_post_thumbnail()) {
           $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'size1' );
         } elseif($options['no_image2']) {
           $image = wp_get_attachment_image_src( $options['no_image1'], 'full' );
         } else {
           $image = array();
           $image[0] = esc_url(get_bloginfo('template_url')) . "/img/common/no_image1.gif";
         }
  ?>
  <article class="item">
   <a class="link animate_background" style="background:none;" href="<?php the_permalink() ?>">
    <div class="image_wrap">
     <div class="image_wrap_inner">
      <?php
           if ($show_category) {
             $area_category = get_the_terms( $post->ID, 'area' );
             if ( $area_category && ! is_wp_error($area_category) ) {
      ?>
      <div class="category">
       <?php
            foreach ( $area_category as $area_cat ) :
              echo "<span>" . esc_html($area_cat->name) . "</span>";
              break;
            endforeach;
       ?>
      </div>
      <?php }; }; ?>
      <div class="image" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;"></div>
     </div>
    </div>
    <h3 class="title"><span><?php the_title(); ?></span></h3>
   </a>
  </article>
  <?php endwhile; ?>
 </div><!-- END .work_list -->
 <?php if($show_button) { ?>
 <div class="link_button">
  <a href="<?php echo esc_url(get_post_type_archive_link('work')); ?>"><?php echo esc_html($button_label); ?></a>
 </div>
 <?php }; ?>
</div><!-- END .index_work_list -->
<?php endif; wp_reset_query(); ?>
<?php
         // carousel -----------------------------------------------------
         } elseif ($content['cb_content_select'] == 'carousel') {
?>
<div class="index_carousel num<?php echo $content_count; ?>">
 <?php
      for($i=1; $i<= 6; $i++):
        $catch = $content['carousel_catch'.$i];
        $title = $content['carousel_title'.$i];
        $sub_title = $content['carousel_sub_title'.$i];
        $use_overlay = $content['carousel_use_overlay'.$i];
        $url = $content['carousel_url'.$i];
        $image_id = $content['carousel_image'.$i];
        if(!empty($image_id)) {
          $image = wp_get_attachment_image_src($image_id, 'size1');
 ?>
 <div class="item item<?php echo $i; ?>">
  <?php if($url){ ?>
  <a class="link animate_background" href="<?php echo esc_url($url); ?>">
  <?php } else { ?>
  <a class="link animate_background no_link" href="#">
  <?php }; ?>
   <div class="caption">
    <?php if($catch) { ?>
    <h2 class="catch rich_font"><span><?php echo nl2br(esc_html($catch)); ?></span></h2>
    <?php }; ?>
    <?php if($title) { ?>
    <h3 class="title"><?php if($sub_title) { echo '<span>' . nl2br(esc_html($sub_title)) . '</span>'; }; ?><?php echo nl2br(esc_html($title)); ?></h3>
    <?php }; ?>
   </div>
   <?php if($use_overlay) { ?>
   <div class="overlay"></div>
   <?php }; ?>
   <div class="image" style="background:url(<?php echo esc_attr($image[0]); ?>) no-repeat center center; background-size:cover;"></div>
  </a>
 </div>
 <?php }; endfor; ?>
</div><!-- END .index_carousel -->
<?php
         // free space -----------------------------------------------------
         } elseif ($content['cb_content_select'] == 'free_space') {
           if (!empty($content['free_space'])) {
?>
<div class="index_free_space cb_contents num<?php echo $content_count; ?>">
 <div class="post_content clearfix">
  <?php echo $content['free_space']; ?>
 </div>
</div><!-- END .cb_contents -->
<?php
           };
         };
       $content_count++;
       endforeach;
     endif;
?>

<?php get_footer(); ?>
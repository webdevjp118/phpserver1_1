<?php get_header(); ?>
  <div class="l-contents l-inner">
    <div class="l-primary">
      <div class="p-archive-header">
      <p class="p-archive-header__desc"><?php _e( 'The page you are looking for is not found', 'tcd-w' ); ?></p>
      </div>
    </div><!-- /.l-primary -->
  </div><!-- /.l-contents -->
<?php get_footer(); ?>

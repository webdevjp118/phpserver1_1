<p><strong>
<?php _e('Related:', 'post-snippets'); ?>
</strong></p>

<p><a href="//www.postsnippets.com" target="_blank"><?php
		_e('Website', 'post-snippets');
		?></a></p>

<p><a href="http://wordpress.org/support/plugin/post-snippets" target="_blank"><?php
_e('Support', 'post-snippets');
?></a></p>

<p><a href="https://github.com/GreenTreeLabs/post-snippets" target="_blank"><?php
_e('GitHub', 'post-snippets');
?></a></p>


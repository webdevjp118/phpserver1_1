tinyMCE.addI18n({en:{
post_snippets:{	
desc : 'Insert a Post Snippet'
}}});

<div class="l-cta">
    <div class="l-wrap">
        <h2 class="cta-ttl">CONTACT</h2>
        <a href="<?php echo get_site_url(); ?>/service/contact" class="cta-btn">お問い合わせ</a>
    </div>
</div>
<?php get_template_part('templates/head'); ?>
<?php get_template_part('templates/header'); ?>
<div class="l-section">
    <div class="l-wrap">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/404-not-found.jpg" alt="">
    </div>
</div>
<?php get_template_part('templates/cta'); ?>
<?php get_template_part('templates/footer'); ?>
</body>
</html>